<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use yii\widgets\Pjax;
use yii\bootstrap\Modal;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use backend\models\CompanyBranch;
use backend\models\Vendor;
use backend\models\Product;
use backend\models\Composition;
use backend\models\Unit;
use backend\models\Stockmaster;
use backend\models\Stockrequest;
use backend\models\Physicianmaster;
$datatables = $dataProvider->getModels();
$session = Yii::$app->session;
use backend\models\Sales;
use backend\models\Saledetail;
use backend\models\Patient;
$this->title = Yii::t('app', 'Sales');
?>
<style>
	.kv-editable-link{
		border-bottom: 0px !important;
	}
	.pagination{display:none;}
</style>
<style>
	#load{display:none;position:fixed;left:128px;top:27px;width:100%;height:100%;z-index:9999;margin-top:20%}
	.dt-buttons{display:none;}
	.wizard .actions{display:none;}
	#datatable-buttons_filter{text-align:left;}
	.chooseaction1:hover{background-color: #ffffff !important;color:#5fbeaa !important}
	.chooseaction1{background-color: #5fbeaa !important;color:#ffffff !important}
	div.dataTables_wrapper div.dataTables_filter input {width:345px !important}
</style>
 <div class="container">
	<div class="row">
<div class="col-sm-12">
<div class="btn-group pull-right m-t-15">
</div>
<h4 class="page-title"> <?= Html::encode($this->title) ?></h4>
<ol class="breadcrumb">
 <li><a href="<?php echo Yii::$app->request->BaseUrl;?>">Home</a></li>
 <li><a href="#"><?php echo $this->title;?></a></li>
</ol>
</div>
</div>
<div id="load"  align="center"><img src="<?= Url::to('@web/dmc.gif') ?>" />Loading...</div>
<div class="row">
<div class="col-sm-12">
<ul class="nav nav-tabs tabs tabs-top">
	       	 <li class="active tab">
                                        <a href="#sales" data-toggle="tab" aria-expanded="false"> 
                                            <span class="visible-xs"><i class="fa fa-home"></i></span> 
                                            <span class="hidden-xs">Add Sale</span> 
                                        </a> 
                           <li class=" tab"> 
                                        <a href="#patient" data-toggle="tab" aria-expanded="false"> 
                                            <span class="visible-xs"><i class="fa fa-user-md"></i></span> 
                                            <span class="hidden-xs">New Patient</span> 
                                        </a> 
                                 </li> 
                                </ul> 
  <div class="tab-content"> 
                                	     <div class="tab-pane active" id="sales"> 
  <?php $form = ActiveForm::begin(['id'=>'searchform', 'action' => ['search'],  'method' => 'post']); ?>

	            <div class="row"><h4>Sale Type</h4></div>
	           	<div class="col-md-4">
 <input name="patienttype"  value="1" type="radio"> InPatient
 <input name="patienttype"  value="2"  type="radio"> OutPatient
    </div>
    <div class="clearfix" style="margin-bottom:30px;">
    	
    </div>
     <div class="row"><h4>Search Exising Patient</h4></div>
		<div class="col-md-2">	
    <?= $form->field($model, 'updated_by')->textinput(['name'=>'patientmobileno','placeholder'=>'Mobile Number'])->label(FALSE); ?>
    </div>
   <div class="col-md-2">
    <?= $form->field($model, 'updated_by')->textinput(['name'=>'mrno','placeholder'=>'MR Number'])->label(false); ?>
   </div>
    <div class="col-md-2">
    <?= $form->field($model, 'updated_by')->textinput(['name'=>'patient_name','placeholder'=>'Name'])->label(false); ?>
   </div>
	  <div class="col-md-3 form-group">
        <?= Html::Button('Go', ['class' => 'btn btn-default waves-effect waves-light dmc']) ?>
    </div>
	 <?php ActiveForm::end(); ?>
	 <div id="search_result">
   </div>
   <div class="row" id="formdetails" style="display: none">
</div>
<div class="clearfix"></div>
                                    </div> 
                                    <div class="tab-pane" id="patient">
                                    	           <div class="row">
                                                   <div class="col-md-12">
										  <?php $form = ActiveForm::begin(['id'=>'wizard-validation-form', 
            ]); 
           
            
            
            
            
            
            
            
            ?>
                                      <div class="col-md-3">
                  	 	
                <?php 
					
					echo $form->field($pmodel, 'medicalrecord_number',['enableAjaxValidation' => true])->textInput(['maxlength' => true,'required'=>'true'])->label("Medical Record Number");
					 
                  ?>
    </div>
    
    
    
       
      <div class="col-md-3">       	  
  <?php   echo $form->field($pmodel, 'gender')->radioList(  ['M' => 'Male', "F" => 'Female','T'=>'Transgender']); ?>
    </div>     
    
         <div class="col-md-3">
    
       <?= $form->field($pmodel, 'physicianname')->dropdownlist($physicianlist,['prompt'=>'Select Physician','class'=>'selectpicker','required'=>'true',
       'data-live-search'=>'true','data-style'=>"btn-default btn-custom"])->label("Physician Name *") ?>
       
      </div> 	     
            <div class="clearfix"></div>
  
    <div class="col-md-3">
    	 <?= $form->field($pmodel, 'firstname')->textInput(['maxlength' => true,'required'=>'true'])->label("First Name *"); ?>
    	
    </div>
    <div class="col-md-3">
    	 <?= $form->field($pmodel, 'lastname')->textInput(['maxlength' => true,'required'=>'true']) ->label("Last Name *");?>
    </div>
     
      
    <div class="col-md-3">
    	
    	<?php if(!$pmodel->isNewRecord)
    	{$dob= $pmodel->dob;
    		$pmodel->dob=date("mm/dd/yyyy",strtotime($dob));}?>
    		 <?= $form->field($pmodel, 'dob')->textInput(['maxlength' => true,'required'=>'true','data-provide' => "datepicker", 
             'data-date-format' => "mm/dd/yyyy",'id'=>'dateofbirth', 'onchange'=>'
                                                    $.get( "'.Url::toRoute('getage').'", { dob: $(this).val() } )
                                                        .done(function( data ) 
                                                        {
                                                        	
                                                           $("#age").val(data);
														   $("#age").load();
														                                                     
                                                        }
                                                    );'])->label("DOB *"); ?>
    		
    		
    </div>
     <div class="col-md-3">
    
     <?= $form->field($pmodel, 'age')->textInput(['maxlength' => true,'readonly'=>'true','placeholder'=>'Age','id'=>'age'])->label("Age"); ?>
       
      </div>
 <div class="clearfix"></div>
    	   	  <div class="col-md-3">
<?= $form->field($pmodel, 'patient_mobilenumber',['enableAjaxValidation' => true])->textInput(['maxlength' => 10,'required'=>'true', 'onkeypress'=>'return isNumber(event)', ])->label("Patient Phone Number"); ?>
     
 </div>
              
                                     

       <div class="col-md-3">
       <?= $form->field($pmodel, 'insurance_type')->dropdownlist($insurancelist,['prompt'=>'Select Insurance Type','id'=>'insurancetype','class'=>'insurancetype form-control',
      'required'=>'true'])->label("Insurance Type *");?>
      </div>
      
         <div class="col-md-3" id="refer" style="display:none;">
      	 <?= $form->field($pmodel, 'reference_number')->textInput(['maxlength' => true])->label("Reference Number"); ?>
      	
      </div>
       <div class="col-md-3">
    	  <?= $form->field($pmodel, 'emailid',['enableAjaxValidation' => true])->textInput(['maxlength' => true])->label("Email ID "); ?>
    </div>
   
    
   
    
    	  <div class="clearfix"></div>
    	
    	  
      <div class="col-md-3">
      	 <?= $form->field($pmodel, 'guardian_name')->textInput(['maxlength' => true])->label("Guardian Name"); ?>
      	
      </div>
          <div class="col-md-3">
        
    	<?= $form->field($pmodel, 'guardian_mobilenumber')->textInput(['maxlength' => 10, 'onkeypress'=>'return isNumber(event)',])->label("Guardian Mobile Number"); ?>
  </div>

       <div class="col-md-3">
   	 <?= $form->field($pmodel, 'address')->textarea(['rows' => 1,'placeholder' =>'Address']); ?>
   </div> 
       <div class="col-md-3">
   	 <?= $form->field($pmodel, 'notes')->textarea(['rows' => 1,'placeholder' =>'Short Notes']); ?>
   </div> 
   
   
   
   
   
    <div class="form-group clearfix">
                                                    <label class="col-lg-12 control-label ">(*) Mandatory</label>
                                                </div>
                                                <div class="row">
                                                	<div class="panel panel-border panel-inverse">
                                                		<div class="panel-heading">
                                                			
                                                		</div>
                                                		<div class="panel-body" id="panelbody" style="display:none;">
                                                			 <table id="datatable-fixed-col2"  class="table table-striped table-hover table-bordered">
                                <thead>
                                <tr>
                                	<th>Add</th>
                                    <th>Stock & Type</th>
                                    <th>Batch No</th>
                                    <th>Available Stock</th>
                                    <th>Stock Code</th>
                                    <th>Composition</th>
                                    <th>Brand</th>
                                    <th>Unit</th>
                                    <th>Expire Date</th>
                                    <th>MRP/Unit</th>
                                </tr>
                                </thead>
                                <tbody>
                                	
                                	<?php 
                                	
                                	 $session = Yii::$app->session;
		                             $role=$session['authUserRole'];
		                             $companybranchid=$session['branch_id'];
									 $saledata=Sales::find()->where(['paid_status'=>'UnPaid'])->andwhere(['branch_id'=>$companybranchid])->all();
                                	 if(count($datatables)>0){
                                		$i=1;
									
                                	foreach ($datatables as $key => $value) {
                                		
                                		$branchid[]=$value->branch_id;
										$newbranchdata=array_intersect_key($branchlist, array_flip($branchid));
									    $branchval=array_values($newbranchdata);
										
										$vendorid[]=$value->stockbrandcode->vendorid;
										$newvendordata=array_intersect_key($vendorlist, array_flip($vendorid));
									    $vendorval=array_values($newvendordata);
										
										$productid[]=$value->stockbrandcode->productid;
										$newproductdata=array_intersect_key($productlist, array_flip($productid));
									    $productval=array_values($newproductdata);
										
										$producttypeid[]=$value->stockbrandcode->product->product_typeid;
										$newproducttypedata=array_intersect_key($producttypelist, array_flip($producttypeid));
									    $producttypeval=array_values($newproducttypedata);
										//composition
										
										$compositionid[]=$value->stockbrandcode->compositionid;
										$newcompositiondata=array_intersect_key($compositionlist, array_flip($compositionid));
									    $compositionval=array_values($newcompositiondata);
										
										//unit
										$unitid[]=$value->stockbrandcode->unitid;
										$newunitdata=array_intersect_key($unitlist, array_flip($unitid));
									    $unitval=array_values($newunitdata);
									   
									    $stockresponseid=$value->stockresponseid;
										$currentqty=0;
										foreach($saledata as $k)
										{
										  $saleid=$k->opsaleid;
											$saledetaildata=Saledetail::find()->where(['opsaleid'=>$saleid])->andwhere(['stockresponseid'=>$value->stockresponseid])->all();
											foreach($saledetaildata as $l)
											{
											$currentqty+=$l->productqty;
										
											
										    }
										}
										$availableqty=($value->total_no_of_quantity)-$currentqty;
										
									
									
									if($availableqty>0)
									{
										
							     echo "<tr>";
								 
								  echo "<td><button type='button' id='btnsubmit".$i."' 
									 dataincrement='".$i."' 
									 class='btn-xs btn-sm  btn-default waves-effect waves-light choose_np' 
									 data-id='".$value->stockresponseid."'>
									 <i class='fa fa-plus'></i>
									 </button></td>";
								 
	                          echo "<td>".$value->stockbrandcode->product->productname."-".$producttypeval[0]."</td><td>".$value->batchnumber."</td><td>".$availableqty."</td>
	                            <td>".$value->stockbrandcode->stockcode."</td> <td>".$compositionval[0]."</td>
	                            <td>".$value->stockbrandcode->brandcode."</td>";
								 echo "<td>".$unitval[0]."</td>";
							     echo "<td>".date("d/m/Y",strtotime($value->expiredate))."</td>";
								 echo "<td>".number_format($value->mrpperunit,2)."</td>";
								 
								 
							    
									 
									 
							     	echo "<input type='hidden' name='branch_id' class='branchid' value='".$value->branch_id."'/>";
								    $newbranchdata=array(); $branchid=array(); $branchval="";
								    $newvendordata=array();  $vendorid=array();  $vendorval="";
									$newproductdata=array(); $productid=array();$productval="";
									$newproducttypedata=array(); $producttypeid=array();$producttypeval="";
									$newcompositiondata=array(); $compositionid=array();$compositionval="";
									$newunitdata=array(); $unitid=array();$stockcodeval="";
                                    echo"</tr>";
									
									}
											
	                               
								 $i++;
                               } 	
} ?>    
                                </tbody>
                            </table>         			
                                                		</div>
                                                	</div>
                                                </div>
                            <div class="clearfix"></div>
                           
                       <div class="row">
                                                	<div class="panel panel-border panel-inverse">
                                                		<div class="panel-heading">
                                                		
                                                		</div>
                                                		<div class="panel-body">      
                                                			 <div  style="white-space: nowrap;
  overflow-x: visible;
  overflow-y: hidden;

  width: auto; ">             
                            
                     <table id="productgrid_np" class="table table-striped table-hover table-bordered">
             <thead id="np_theaddata" style="display:none;">
           <!--  <th>S.No</th>-->
            	<th>Stock</th><th>Drug</th> <th>Brand & <br>StockCode</th><th>Batch No<br>/Current Stock</th>
				<th>Quantity</th><th>Unit Form</th><th>Total Units</th><th>Price/Qty</th>
				<th id="gstper">GST %</th><th id="gstval">GST Value</th><th> Discount <br> Type</th><th> Disc %</th>
				<th> Disc.Value</th>
													<th >Total Price</th><th>Del</th>
             </thead>  <?php $i=0;?>
         <tbody  id="formdetails_np" >

</tbody>

<tr id="totalprice_np_row" style="display:none;"><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
	<td id="totalprice_np_gstlabel">Tot.Gst</td>
	
	<td style="text-align:right;" id="td1"><span id="totalgstnp">Rs.0</span></td>
	<td id="td2"></td><td id="td3">Tot.Disc</td>
<td style="text-align:right;"><span id="totaldiscountnp">Rs.0</span></td>
<td style="text-align:right;"><span id="total_np">Tot.Price :Rs.0</span>
	<input type="hidden" id="totalprice_np" name="totalprice" /></td><td></td></tr>


    
     <tr id="totalprice_np_label" style="display:none;"><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
     	<td></td><td id="totalprice_np_cgstlabel">Tot.Cgst </td>
	<td id="totalprice_np_cgst" style="display:none;text-align:right;"><span id="totalcgstnp">Rs.0</span></td>
	<td><b>Overall <br>Discount <br>Type</b></td><td><b>Disc(%)<br>Amt</b></td>
    <td><b>Overall <br>Discount</b></td>
    <td><b>Overall <br>Total</b></td><td></td></tr>
    
    
<tr id="ovaralltotalprice_np" style="display:none;"> <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
<td id="totalprice_np_sgstlabel">Tot.Sgst</td>
	<td id="totalprice_np_sgst" style="display:none;text-align:right;"><span id="totalsgstnp">Rs.0</span></td>	
	
<td>Flat <input class="overalldiscounttype_np" id="overalldiscounttype_np" name="overalldiscounttype" value="flat" type="radio" checked="true">
 %<input class="overalldiscounttype_np" id="overalldiscounttype_np" name="overalldiscounttype" value="percent"  type="radio" ></td>
  <td>
 <input type="text" name="overalldiscount[]" placeholder="Discount" class="form-control overalldiscountpercent" required="true"   id="overalldiscountpercent"  value="0" />
 </td>
 <td>
 <input type="text"  readonly="true" name="overalldiscountamount[]" value="0" class="form-control overalldiscountamount"   required="true" id="overalldiscountamount"/>
 </td>
 <td>
 <input type="text" name="overalltotal[]"  readonly="true" required="true"   value="0" class="form-control overalltotal" id="overalltotal" required="true" readonly="true" /> 
 </td><td></td></tr>
<tr id="btn_np" style="display:none;"><td colspan="9" align="right">
	 <span id="loadtex" style="display: none; "></span>
 <?= Html::Button($pmodel->isNewRecord ? '<i class="fa fa-fw fa-save"></i>Save' : '<i class="fa fa-fw fa-save "></i>Update', ['class' => $pmodel->isNewRecord ? 'btn btn-success savevalue_np' : 'btn btn-primary ']) ?>
 <td ><p id="invoice" style="display:none;"></p>
	</td><td></td><td></td><td></td><td id="rem1"></td><td id="rem2"></td>
	</tr>
		 </table>
        </div>
</div>
</div>
</div>

      <?php ActiveForm::end(); ?> 
      
                        	</div>
                    	</div>
</div>
</div>
</div>
</div>
</div>
 <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script>
    $(document).ready(function()
    {
             $('body').on("click",".modalView",function(){
             var PageUrl = $(this).attr('value');
             $('#operationalheader').html('<span> <i class="fa fa-fw fa-th-large"></i>View Stock Audit</span>');
             $('#operationalmodal').modal('show').find('#modalContenttwo').load(PageUrl);
             return false();
             
         });
           });
         
</script>
<script>

function alphaOnly(event) {
  var key = event.keyCode;
  return ((key >= 65 && key <= 90) || key == 8);
};
 $(document).ready(function()
 {

 $('body').on("click",'.dmc',function(){

 var form = $("#searchform");
 var formData = form.serialize();
 var ptype = $("#searchform input[name='patienttype']:checked").val();
if (typeof(ptype) == "undefined")
 {
 
	  swal("Sale Type Required");
	 
 }
 else
 {
 	 $.ajax({
        url: form.attr("action"),
        type: form.attr("method"),
        data: formData,
        success: function (data) {
        	$("#search_result").html(data);
        	TableManageButtons.init();
        	$(".dt-buttons").hide();
        }
     });
 }
 


	});
	

	
	
	
	
	
	
	
	
		 $('body').on("click",'.savevalue_np',function(){
 var form = $("#wizard-validation-form");
 var formData = form.serialize();
 $form_container=$("#wizard-validation-form");
   	 $form_container.validate().settings.ignore = ":disabled,:hidden";
   var chkform=$form_container.valid();
   if(chkform==true){
   	 	var k=0;
var inps = document.getElementsByName('dataincrement[]');
for (var i = 0; i <inps.length; i++)
 {
var inp=inps[i];
 var inc=inp.value;
     var totalstock=parseFloat($("#availablestock" + inc).val());
  	 	 var uq_1=parseFloat($("#totalunits" + inc).val());
          if(uq_1>totalstock)
          {
          	var k=1;
          }
          
            if(uq_1<=0)
          {
          	var k=2;
          }
}

var overalltotal=parseFloat($("#overalltotal").val());
if(overalltotal<=0)
{
	k=3;
}
 if(k==0)
  {
  	$.ajax({
        url:'<?php echo Yii::$app->homeUrl ?>?r=sales/create',
        type: 'post',
       data: formData,
        success: function (data) {
        	$("#load").show();
	    if(data=="A"){
		$("#load").hide();
		$("#loadtex").text("Some Stock Recently Assigned to Sale. Stock Not available Now.");
		$("#loadtex").css('color','green ');
	    $("#loadtex").show(4);
		}
		
		else
	    {
	    	var data1=data.split("=")[0];
        	var data2=data.split("=")[1];
        	if(data1=="Y")
        	{
       $("#load").hide();
	   $(".savevalue_np").hide();
		$("#loadtex").text("Successfully Saved.");
		$("#loadtex").css('color','green ');
	    $("#loadtex").show(4);
	     $("#invoice").show();
	    $("#invoice").find('a.btn').remove();
	      $("#invoice").append("<a target='_blank' class='btn btn-default' href='<?php echo Yii::$app->homeUrl ?>?r=sales/invoice&id="+data2+"'>Invoice</a>" );
        	}
		}
        }
     });
  }
  
   else if(k==2){
  	   swal({
                title: "Are you sure?",
                text: "Total Units Required Some Stock",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: "Yes",
                closeOnConfirm: false
            });
   }
   
    else if(k==3){
  	   swal({
                title: "Are you sure?",
                text: "Overall Total Less than zero",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: "Yes",
                closeOnConfirm: false
            });
   }
        else{
  	   swal({
                title: "Are you sure?",
                text: "Check Your Units is greater than Available Stock",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: "Yes",
                closeOnConfirm: false
            });
            }
    }
	});
	$('body').on("click",'.product_add',function(){
 $("#load").fadeIn("slow");
  var form = $("#wizard-validation-form1");
  var formData = form.serialize();
 $.ajax({
        url:'<?php echo Yii::$app->homeUrl ?>?r=sales/productdetails',
        type: 'post',
       data: formData,
        success: function (data) {
        	$("#load").fadeOut("slow");
        	$("#productlist").html(data);
        	$(".dt-buttons").hide();
        }
     });
	});
		$('body').on("click",'.product_add1',function(){
 $("#load").fadeIn("slow");
  var form = $("#wizard-validation-form");
 var formData = form.serialize();
 $.ajax({
        url:'<?php echo Yii::$app->homeUrl ?>?r=sales/productdetails1',
        type: 'post',
       data: formData,
        success: function (data) {
        	$("#load").fadeOut("slow");
        	$("#productlist1").html(data);
        	$(".dt-buttons").hide();
        }
     });
	});
$('body').on("input",'.productqty',function(evt){	
   var self = $(this);
   self.val(self.val().replace(/[^0-9]/g, ''));
   if ((evt.which != 46 || self.val().indexOf('.') != -1) && (evt.which < 48 || evt.which > 57)) 
   {
     evt.preventDefault();
   }
   var valz=$(this).val();
   var attz=$(this).attr('datacls');
   var perprice=$(this).attr('dataprice');
   var totalprice=(perprice)*(valz);
   $("#"+attz).text("Rs."+totalprice);
   $("#"+attz+"1").val(totalprice);
   var totla_each = 0;
   $('.pricez').each(function(){
   	 totla_each += parseFloat(this.value) || 0;
});
$("#total").text("Rs."+totla_each);
$("#totalprice").val(totla_each);
 });
 $('body').on("input",'.productqty_ep',function(evt)
 {		
   var self = $(this);
   self.val(self.val().replace(/[^0-9]/g, ''));
   if ((evt.which != 46 || self.val().indexOf('.') != -1) && (evt.which < 48 || evt.which > 57)) 
   {
     evt.preventDefault();
   }
   var valz1=$(this).val();
   var attr=$(this).attr('datacls_ep');
   var perprice1=$(this).attr('dataprice_ep');
   var totalprice1=(perprice1)*(valz1);
   var temp=attr+"1";
   $("#"+attr).text("Rs."+totalprice1);
   $("#"+temp).val(totalprice1);
   var totla_each1 = 0;
   $('.price_ep').each(function(){
   	 totla_each1 += parseFloat(this.value) || 0;
   
});
$("#total_ep").text("Rs."+totla_each1);
$("#totalprice_ep").val(totla_each1);
 });
 
  $('body').on("input",'.productqty_np',function(evt)
  {	
   var self = $(this);
   self.val(self.val().replace(/[^0-9]/g, ''));
   if ((evt.which != 46 || self.val().indexOf('.') != -1) && (evt.which < 48 || evt.which > 57)) 
   {
     evt.preventDefault();
   }
   var valz1=$(this).val();
   var attr=$(this).attr('datacls_np');
   var perprice1=$(this).attr('dataprice_np');
   var totalprice1=(perprice1)*(valz1);
   var temp=attr+"1";
   $("#"+attr).text("Rs."+totalprice1);
   $("#"+temp).val(totalprice1);
   var totla_each1 = 0;
   $('.price_np').each(function(){
   	 totla_each1 += parseFloat(this.value) || 0;
});

$("#total_np").text("Rs."+totla_each1);
$("#totalprice_np").val(totla_each1);
 });
$('body').on("click",'.chooseaction',function(){
	var dataid=$(this).attr('data-id');
	$("#load").fadeIn("slow");
	$("#formdetails").fadeOut("slow");
	$.ajax({
        url:'<?php echo Yii::$app->homeUrl ?>?r=sales/patientdetails&id='+dataid,
        type: "post",
        success: function (data) {
        $("#formdetails").empty();
        $("#formdetails").html(data);
         $("#load").fadeOut("slow");
          $("#gen").attr('disabled',true).selectpicker('refresh');
        $("#vendor_idz").selectpicker('refresh');
        $("#product_idz").selectpicker('refresh');
        $("#formdetails").fadeIn("slow");
        }
     });
	})
	
	$('body').on("click",'.choose_np',function(){
	var y = $('#productgrid_np >tbody >tr').length;
	var dataid=$(this).attr('data-id');
	var price = $('.price').val();
	var branch = $('.branchid').val();
	$("#load").fadeIn("slow");
	$("#formdetails").fadeOut("slow");
	var inc = $(this).attr('dataincrement');
	var selectedVal = "";
    var selected = $("#radioDiv input[type='radio']:checked");
    if (selected.length > 0) 
    {
    selectedVal = selected.val();
    }
if(selectedVal==1 || selectedVal==2)
{
 var form = $("#wizard-validation-form");
 var formData = form.serialize();
 $form_container=$("#wizard-validation-form");
   	 $form_container.validate().settings.ignore = ":disabled,:hidden";
   	  $("#load").fadeOut("slow");	
   var chkform=$form_container.valid();
   if(chkform==true){
		$("#btnsubmit"+ inc).prop('disabled', true);
	    $('#np_theaddata').show();
        $('#totalprice_np_row').show();
        $('#btn_np').show();
        $('#totalprice_np_cgst').show();
        $('#totalprice_np_sgst').show();
        $('#totalprice_np_label').show();
        $("#ovaralltotalprice_np").show();
        
	if(selectedVal==1)
	{
		  $("#gstper").hide();
		  $("#gstval").hide();
		  $("#totalprice_np_cgst").hide();
		  $("#totalprice_np_sgst").hide();
		  $("#totalgstnp").hide();
		  $("#totalprice_np_gstlabel").hide();
		   $("#td1").hide();
		    $("#rem1").hide();
		    $("#rem2").hide();
		  $("#totalprice_np_cgstlabel").hide();
		  $("#totalprice_np_sgstlabel").hide();
		   
	}
	else{
		 $("#gstper").show();
		 $("#gstval").show();
		 $("#totalprice_np_cgst").show();
		 $("#totalprice_np_sgst").show();
		 $('#totalprice_np_label').show();
		 $("#ovaralltotalprice_np").show();
		 $("#totalprice_np_gstlabel").show();
		 $("#totalprice_np_cgstlabel").show();
		 $("#totalprice_np_sgstlabel").show();
		 $("#totalgstnp").show();  
		  $("#rem1").show();
		    $("#rem2").show();
		   $("#td1").show();
	}
   		$.ajax({
   			
       url:'<?php echo Yii::$app->homeUrl ?>?r=sales/productdetail_np&id='+dataid+"&price="+price+"&branch_id="+branch+"&ptype="+selectedVal+"&autonumber="+inc,
        type: "post",
        success: function (data) {
       // $("#formdetails1").empty();
       
        var r = $("#formdetails_np").append(data);
       if(data=="Y"){
		        	 $("#load").fadeOut("slow");	
		        	 noti();
		        	// $("#formdetails1").fadeOut("slow");
		        	}

         $("#load").fadeOut("slow");
          $("#gen").attr('disabled',true).selectpicker('refresh');
        $("#vendor_idz").selectpicker('refresh');
        $("#product_idz").selectpicker('refresh');
        $("#formdetails").fadeIn("slow");
        }
     });
   }
   	
   	else{
			swal("Please Fill Required Fields!");
			$("#load").fadeOut("slow");	
		    $("#formdetails").fadeIn("slow");
		       }
}
else{
	  swal("Please Fill Patient Type ");
	  $("#load").fadeOut("slow");	
	  $("#formdetails").fadeIn("slow");
}
	})
	
	
	
	
	
	
	
	
	
	<?php 
if(isset($_GET['status'])){?>
 noti();
<?php }?>
});
function noti () {
 swal("Successfully Added!", "", "success")
}
$('body').on("click",'.demo',function(e){
return false;
	
});
</script> 
<script>
 $(document).ready(function()
 {
 	 $(document.body).on('change', '#insurancetype', function ()
 	  {
        var val = $('#insurancetype').val();
        if(val == 3 || val=="") 
        { $('#refer').hide();
         $("#datatable-fixed-col2").dataTable().fnDestroy();
               $('#panelbody').show();
          $("#datatable-fixed-col2").length && $("#datatable-fixed-col2").DataTable({
             scrollY: "200px",
            scrollX: false,
            scrollCollapse: true,
            paging: false,
            fixedColumns: {
                leftColumns: 1,
                rightColumns: 1
            },
            "order": [[ 8, "asc" ]],
       });
        }
         else 
         {   $('#refer').show();
             $("#datatable-fixed-col2").dataTable().fnDestroy();
             $('#panelbody').show();
         	 $("#datatable-fixed-col2").length && $("#datatable-fixed-col2").DataTable({
             scrollY: "200px",
            scrollX: false,
            scrollCollapse: true,
            paging: false,
            fixedColumns: {
                leftColumns: 1,
                rightColumns: 1
            },
            
            "order": [[ 8, "desc" ]],
       });
         }
    });
    });
</script>