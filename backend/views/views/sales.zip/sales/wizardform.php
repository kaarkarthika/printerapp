<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use backend\models\Vendor;
use backend\models\Product;
use backend\models\Composition;
use backend\models\Unit;
use backend\models\Stockmaster;
use backend\models\Stockrequest;
use yii\helpers\Url;
use backend\models\Sales;
use backend\models\Saledetail;
use backend\models\Patient;
$datatables = $dataProvider->getModels();
?>
<style>
	.pagination{display:none;}
.dataTables_filter {
   width: 100%;float:right;text-align:left;
}
</style>
<?php $form = ActiveForm::begin(['id' => 'wizard-validation-form1']);?>
<div class="col-sm-12">
<div class="panel panel-border panel-inverse">
<div class="panel-heading">
 </div>
 <div class="panel-body">
		
		<?php if($pid!="")
			{
				$model = Patient::find() -> where(['patient_id' => $pid]) -> one();
				echo '<div class="row"><h4>Patient Exists.Update Patient Below and make Sale.</h4></div>';
			} 

			else
				{
					$model=new Patient();
					echo '<div class="row"><h4>No Patient Found.Add New Patient Below and make Sale.</h4></div>';
				}
				
				
				
				?>
				<div class="clearfix" style="margin-top:30px;"></div>
				 <div class="col-md-3">
 
		<?= $form -> field($model, 'medicalrecord_number') -> textInput(['maxlength' => true, 'class' => 'required form-control', 'id' => 'mr','readonly'=>$readonly,
		]);?>
	
 </div>
				


		 <div class="col-md-3">	
 
		<?= $form -> field($model, 'firstname') -> textInput(['maxlength' => true, 'class' => 'required form-control', 'id' => 'name', 'readonly'=>$readonly,
		]);?>
		
 </div>
 	 <div class="col-md-3">	
 
		<?= $form -> field($model, 'lastname') -> textInput(['maxlength' => true, 'class' => 'required form-control', 'id' => 'name',  'readonly'=>$readonly,
		]);?>
		
 </div>
 					 <div class="col-md-3">	

		<?php echo $form -> field($model, 'emailid') -> textinput(['id' => 'emailid' ]) ;
		?>
		
 </div>
 

 
   <div class="col-md-3">
    	<?= $form->field($model, 'patient_mobilenumber',['enableAjaxValidation' => true])->textInput(['maxlength' => 10,'required'=>'true', 'onkeypress'=>'return isNumber(event)', 

])->label("Patient PhoneNo"); ?>
    		
    </div>
  <div class="col-md-3">       	  
  <?php   echo $form->field($model, 'gender')->radioList(  ['M' => 'M', "F" => 'F','T'=>'T']); ?>
    </div> 
 <div class="col-md-3">
 <?= $form->field($model, 'physicianname')->dropdownlist($physicianlist,['prompt'=>'--Physician--','required'=>'true'])->label("Physician Name *") ?>
</div>
<div class="col-md-3">
<?php if(!$model->isNewRecord)
    	{$dob= $model->dob;
    		$model->dob=date("d/m/Y",strtotime($dob));}
    		?>
    		 <?= $form->field($model, 'dob')->textInput(['maxlength' => true,'required'=>'true','data-provide' => "datepicker", 
             'data-date-format' => "d/m/Y",'id'=>'dateofbirth', 'onchange'=>'
                                                    $.get( "'.Url::toRoute('getage').'", { dob: $(this).val() } )
                                                        .done(function( data ) 
                                                        {
                                                           $("#age1").val(data);
														   $("#age1").load();                              
                                                        }
                                                    );'])->label("DOB *"); 
             ?>        
     
 </div>
 <div class="col-md-3">
       <?php echo $form->field($model, 'insurance_type')->dropdownlist($insurancelist,['prompt'=>'--Insurance Type','id'=>'insurancetype',
       'class'=>'insurancetype form-control',
      'required'=>'true','value'=>''])->label("Insurance Type *");?>
      </div>
      
         <div class="col-md-3" id="refer" style="display:none;">
      	 <?=$form->field($model, 'reference_number')->textInput(['maxlength' => true])->label("Reference Number"); ?>
      	
      </div>
     



  <div class="col-md-3">
      	 <?= $form->field($model, 'guardian_name')->textInput(['maxlength' => true])->label("Guardian Name"); ?>
      	
      </div>
          <div class="col-md-3">
        
    	<?= $form->field($model, 'guardian_mobilenumber')->textInput(['maxlength' => 10, 'onkeypress'=>'return isNumber(event)',])->label("Guardian Mobile Number"); ?>
  </div>

       <div class="col-md-3">
   	 <?= $form->field($model, 'address')->textarea(['rows' => 1,'placeholder' =>'Address']); ?>
   </div> 
       <div class="col-md-3">
   	 <?= $form->field($model, 'notes')->textarea(['rows' => 1,'placeholder' =>'Short Notes']); ?>
   </div> 
   <div class="col-md-3">
   	 <?php echo $form->field($model, 'age')->textInput(['maxlength' => true,'readonly'=>'true','placeholder'=>'Age','readonly'=>'true','id'=>'age1'])->label("Age"); ?>
   	
   </div>

		 
		 
	</div>
	</div>
	</div>	
		 
	<div class="col-sm-12">
<div class="panel panel-border panel-inverse" style="display:none;" id="addsalepanel">
<div class="panel-heading">
 </div>
 <div class="panel-body">	 
		 

  <table id="datatable-fixed-col4" class="table table-striped table-hover table-bordered">
                                <thead>
                                <tr>  <th>Add</th>
                                      <th>Stock&Type</th>
                                      <th>Batch No</th>
                                      <th>Available Stock</th>
                                      <th>Stockcode</th>
                                      <th>Composition</th>
                                      <th>Brand</th>
                                      <th>Unit</th>
                                      <th>Expire Date</th>
                                      <th>MRP/Unit</th>
                                </tr>
                                </thead>
                                <tbody>
                                	<?php 
                                	if(count($datatables)>0){
                                		$i=1;
										
											 $session = Yii::$app->session;
		$role=$session['authUserRole'];
		$companybranchid=$session['branch_id'];
	
						
										
										$saledata=Sales::find()->where(['paid_status'=>'UnPaid'])->andwhere(['branch_id'=>$companybranchid])->all();
                                	foreach ($datatables as $key => $value) {
                                		
                                		$branchid[]=$value->branch_id;
										$newbranchdata=array_intersect_key($branchlist, array_flip($branchid));
									    $branchval=array_values($newbranchdata);
										
										$vendorid[]=$value->stockbrandcode->vendorid;
										$newvendordata=array_intersect_key($vendorlist, array_flip($vendorid));
									    $vendorval=array_values($newvendordata);
										
										$productid[]=$value->stockbrandcode->productid;
										$newproductdata=array_intersect_key($productlist, array_flip($productid));
									    $productval=array_values($newproductdata);
									    $producttypeid[]=$value->stockbrandcode->product->product_typeid;
										$newproducttypedata=array_intersect_key($producttypelist, array_flip($producttypeid));
									    $producttypeval=array_values($newproducttypedata);
										//composition
										
										$compositionid[]=$value->stockbrandcode->compositionid;
										$newcompositiondata=array_intersect_key($compositionlist, array_flip($compositionid));
									    $compositionval=array_values($newcompositiondata);
										
										//unit
										$unitid[]=$value->stockbrandcode->unitid;
										$newunitdata=array_intersect_key($unitlist, array_flip($unitid));
									    $unitval=array_values($newunitdata);
									   $stockresponseid=$value->stockresponseid;
										$currentqty=0;
										foreach($saledata as $k)
										{
										  $saleid=$k->opsaleid;
											$saledetaildata=Saledetail::find()->where(['opsaleid'=>$saleid])->andwhere(['stockresponseid'=>$value->stockresponseid])->all();
											foreach($saledetaildata as $l)
											{
											$currentqty+=$l->productqty;	
										    }
										}
										$availableqty=($value->total_no_of_quantity)-$currentqty;
										if($availableqty>0)
										{
										     echo "<tr>";
											
									  echo"<td><button type='button' id='buttonsubmit".$i."' dataincrement='".$i."' class='btn-xs btn-sm btn-icon btn-default waves-effect waves-light choose_ep' data-id='".$value->stockresponseid."'>
								  <i class='fa fa-plus'></i>
								 </button></td>";		
                               echo "<td>".$value->stockbrandcode->product->productname."-".$producttypeval[0]."</td> <td>".$value->batchnumber."</td><td>".$availableqty."</td>
                                <td>".$value->stockbrandcode->stockcode."</td> <td>".$compositionval[0]."</td>
                                  <td>".$value->stockbrandcode->brandcode."</td>";
								 echo "<td>".$unitval[0]."</td>";
								 	echo "<td>".date("d/m/y",strtotime($value->expiredate))."</td>";
								   echo "<td>".number_format($value->mrpperunit,2)."</td>";
								   
							 echo "<input type='hidden' name='branch_id' class='branchid' value='".$value->branch_id."'/>";
								    $newbranchdata=array(); $branchid=array(); $branchval="";
								    $newvendordata=array();  $vendorid=array();  $vendorval="";
									$newproductdata=array(); $productid=array();$productval="";
									$newproducttypedata=array(); $producttypeid=array();$producttypeval="";
									$newcompositiondata=array(); $compositionid=array();$compositionval="";
									$newunitdata=array(); $unitid=array();$stockcodeval="";
                                    
                                 echo"</tr>";	
										}
										
                            
								 $i++;
                               } 

	} ?>
                                
                                </tbody>
                            </table>
                      <div  style="white-space: nowrap;
  overflow-x: visible;
  overflow-y: hidden;

  width:auto; ">                     			
                             <table id="productgrid_ep" class="table table-striped table-hover table-bordered">
             <thead id="ep_theaddata" style="display:none;">
             <th>Stock</th>
             <th >Drug</th>
             <th>Brand & <br>StockCode</th>
              <th>Batch No<br>/Current Stock</th>
             <th>Quantity</th>
              <th>UnitForm</th>
              <th>TotalUnits</th>
             <th>Price/Qty</th>
			<th id="gstperep">GST (%)</th>
              <th id="gstvalep">GSTValue</th>
               <th> Disc<br>Type</th>
              <th> Disc</th>
                <th>Discount <br>Value</th>
             <th>Total Price</th>
              <th>Del</th>
             </thead>  
<tbody id="formdetails_ep">
</tbody>
<tr id="totalprice_ep_row" style="display:none;">
	<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td id="totalprice_ep_gstlabel">Tot.Gst</td>
	<td style="text-align:right;" id="td1"><span id="totalgstep">Rs.0</span></td>
	<td id="td2"></td><td id="td3">Tot.Disc</td>
<td style="text-align:right;"><span id="totaldiscountep">Rs.0</span></td>
<td style="text-align:right;"><span id="total_ep">Tot.Price :Rs.0</span>
<input type="hidden" id="totalprice_ep" name="totalprice" /></td><td></td>
</tr>

    
     <tr id="totalprice_ep_label" style="display:none;"><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
     	<td></td><td id="totalprice_ep_cgstlabel">Tot.Cgst </td>
	<td id="totalcgstep" style="text-align:right;">Rs.0</td>
	<td><b>Overall <br>Discount <br>Type</b></td><td><b>Disc(%)<br>Amt</b></td>
    <td><b>Overall <br>Discount</b></td>
    <td><b>Overall <br>Total</b></td><td></td></tr>
    
    
<tr id="ovaralltotalprice_ep" style="display:none;"> <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
<td id="totalprice_ep_sgstlabel" style="display:none;text-align:right;">Tot.Sgst</td>

<td id="totalsgstep" style="text-align:right;">Rs 0</td>

<td>Flat <input class="overalldiscounttype_ep" id="overalldiscounttype_ep" name="overalldiscounttypeep" value="flat" type="radio" checked="true">
 %<input class="overalldiscounttype_ep" id="overalldiscounttype_ep" name="overalldiscounttypeep" value="percent"  type="radio" ></td>
  <td>
 <input type="text" name="overalldiscountep" placeholder="Discount" class="form-control overalldiscountpercentep" required="true"   id="overalldiscountpercentep"  value="0" />
 </td>
 <td>
 <input type="text"  readonly="true" name="overalldiscountamountep" value="0" class="form-control overalldiscountamountep"   required="true" id="overalldiscountamountep"/>
 </td>
 <td>
 <input type="text" name="overalltotalep"  readonly="true" required="true"   value="0" class="form-control overalltotalep" id="overalltotalep" required="true" readonly="true" /> 
 </td><td></td></tr>
 
<tr id="btn_ep" style="display:none;"><td colspan="12" align="right">
	 <span id="loadtex1" style="display: none; "></span>
	 <?= Html::Button($pmodel->isNewRecord ? '<i class="fa fa-fw fa-save"></i>Save' : '<i class="fa fa-fw fa-save "></i>Update', ['class' => $pmodel->isNewRecord ? 'btn btn-success savevalue_ep' : 'btn btn-primary ']) ?>
</td> <td><p id="invoice1" style="display:none;"><td id="rem1"></td><td id="rem2"></td></p>
	</td></tr>
 </table>

	
</div>

</div>
</div>
<?php	ActiveForm::end();?>
<script>
 $(document).ready(function()
 {
$('.dataTables_filter').addClass('pull-left');
$('#datatable-fixed-col4').DataTable
({
            scrollY: "200px",
            scrollX: false,
            scrollCollapse: true,
            paging: false,
            fixedColumns: {
                leftColumns: 1,
                rightColumns: 1
            }
        });
$('body').on("click",'.choose_ep',function()
	{
    var y = $('#productgrid_ep >tbody >tr').length;
	var dataid=$(this).attr('data-id');
	var price = $('.price').val();
	var branch = $('.branchid').val();
	var ptype = $("#searchform input[name='patienttype']:checked").val();
	$("#load").fadeIn("slow");
	var inc = $(this).attr('dataincrement');
	var form = $("#wizard-validation-form1");
    var formData1 = form.serialize();
    $form_container=$("#wizard-validation-form1");
    $form_container.validate().settings.ignore = ":disabled,:hidden";
   	$("#load").fadeOut("slow");	
    var chkform=$form_container.valid();
    if(chkform==true){
   	
   	$("#buttonsubmit"+ inc).prop('disabled', true);
   	if(ptype==1)
	  {
		  $("#gstperep").hide();
		  $("#gstvalep").hide();
		  $("#totalgstep").hide();
		  $("#totalcgstep").hide();
		  $("#totalsgstep").hide();
		  $("#totalprice_ep_gstlabel").hide();
		  $("#td1").hide();
		  $("#rem1").hide();
		  $("#rem2").hide();
		  $("#totalprice_ep_cgstlabel").hide();
		  $("#totalprice_ep_sgstlabel").hide();
		  $("#totalprice_ep_cgst").hide();
	}
	else{
		  $("#gstperep").show();
		  $("#gstvalep").show();
		  $("#totalgstep").show();
		  $("#totalprice_ep_gstlabel").show();
		  $("#td1").show();
		  $("#rem1").show();
		  $("#rem2").show();
		  $("#totalprice_ep_cgstlabel").show();
		  $("#totalprice_ep_sgstlabel").show();
		  $("#totalcgstep").show();
		  $("#totalsgstep").show();
	}
	
	
		$.ajax(
		{
        url:'<?php echo Yii::$app->homeUrl ?>?r=sales/productdetail_ep&id='+dataid+"&branch_id="+branch+"&ptype="+ptype+"&autonumber="+inc,
        type: "post",
         data: formData1,
        success: function (data)
         {
      $('#ep_theaddata').show();
        var r = $("#formdetails_ep").append(data);
         $('#totalprice_ep_row').show();
         $('#totalprice_ep_cgst').show();
         $('#totalprice_ep_sgst').show();
         $('#totalprice_ep_label').show();
         $('#ovaralltotalprice_ep').show();
         $('#btn_ep').show();
         $("#load").fadeOut("slow");
        if(data=="Y")
        {
		$("#load").fadeOut("slow");	
		}
        $("#load").fadeOut("slow");
        $("#gen").attr('disabled',true).selectpicker('refresh');
        $("#vendor_idz").selectpicker('refresh');
        $("#product_idz").selectpicker('refresh');
        $("#formdetails").fadeIn("slow");
        }
     }
     );
   }
   
     	else{
			swal("Please Fill Required Fields!");
			$("#load").fadeOut("slow");	
		    $("#formdetails").fadeIn("slow");
		       }
	})
	});
</script>
<script>
 $(document).ready(function()
 {
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	 $(document.body).on('change', '#insurancetype', function ()
 	  {
        var val = $('#insurancetype').val();
     if( val=="")
        {
        	swal("Please Fill Insurance Type");
			$("#load").fadeOut("slow");	
		    $("#formdetails").fadeIn("slow");
        }
        else
        {
        	      if(val == 3 || val=="") 
        { $('#refer').hide();
         $("#datatable-fixed-col4").dataTable().fnDestroy();
               $('#addsalepanel').show();
          $("#datatable-fixed-col4").length && $("#datatable-fixed-col4").DataTable({
             scrollY: "200px",
            scrollX: false,
            scrollCollapse: true,
            paging: false,
            fixedColumns: {
                leftColumns: 1,
                rightColumns: 1
            },
            "order": [[ 9, "asc" ]],
       });
        }
         else 
         {   $('#refer').show();
             $("#datatable-fixed-col4").dataTable().fnDestroy();
             $('#addsalepanel').show();
         	 $("#datatable-fixed-col4").length && $("#datatable-fixed-col4").DataTable({
             scrollY: "200px",
            scrollX: false,
            scrollCollapse: true,
            paging: false,
            fixedColumns: {
                leftColumns: 1,
                rightColumns: 1
            },
         
            "order": [[ 9, "desc" ]],
       });
         }
        }
  
    });
    
     $('body').on("click",'.savevalue_ep',function(){
 var form = $("#wizard-validation-form1");
 var formData = form.serialize();
 $form_container=$("#wizard-validation-form1");
   	 $form_container.validate().settings.ignore = ":disabled,:hidden";
   var chkform=$form_container.valid();
   if(chkform==true){
   	   	 	var k=0;
var inps = document.getElementsByName('dataincrement[]');
for (var i = 0; i <inps.length; i++)
 {
var inp=inps[i];
var inc=inp.value;
var totalstock1=parseFloat($("#availablestock" + inc).val());
var uq_2=parseFloat($("#totalunits" + inc).val());
          if(uq_2>totalstock1)
          {
          	var k=1;
          }
          
          if(uq_2<=0)
          {
          	var k=2;
          }
}

var overalltotal=parseFloat($("#overalltotalep").val());

if(overalltotal<=0)
{
	k=3;
}


if(k==0)
{
	$.ajax({
        url:'<?php echo Yii::$app->homeUrl ?>?r=sales/savesales',
        type: 'post',
        data: formData,
        success: function (data) {
        $("#load").show();
        if(data=="A"){
		$("#load").hide();
		$("#loadtex").text("Some Stock Recently Assigned to Sale. Stock Not available Now.");
		$("#loadtex").css('color','green ');
	    $("#loadtex").show(4);
		}
		else{
			var data1=data.split("=")[0];
        	var data2=data.split("=")[1];
			if(data1=="Y")
	    {
	    $("#load").hide();
	    $(".savevalue_ep").hide();
		$("#loadtex1").text("Successfully Saved.");
		$("#loadtex1").css('color','green ');
	    $("#loadtex1").show(4);
	    $("#invoice1").show();
	    $("#invoice1").find('a.btn').remove();
	    $("#invoice1").append("<a target='_blank' class='btn btn-default' href='<?php echo Yii::$app->homeUrl ?>?r=sales/invoice&id="+data2+"'>Invoice</a>" );
		}
		}
        }
     });
}
 else if(k==2)
 {
  	   swal({
                title: "Are you sure?",
                text: "Total Units Required",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: "Yes",
                closeOnConfirm: false
            });
   }
   
    else if(k==3){
  	   swal({
                title: "Are you sure?",
               text: "Total Units Required Some Stock",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: "Yes",
                closeOnConfirm: false
            });
                }
        else{
  	         swal({
                title: "Are you sure?",
                text: "Check Your Units is greater than Available Stock",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: "Yes",
                closeOnConfirm: false
            });
   }
   
    }
	});
    
    });
</script>