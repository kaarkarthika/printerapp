<?php
   use yii\helpers\Html;
   use yii\widgets\ActiveForm;
   use yii\helpers\Url;
   $this->title="Create Stock";
   
   ?>

<style>
   #load{display: none;position: fixed;left: 128px;top: 27px;width: 100%;height: 100%;z-index: 9999;/*opacity: 0.6;*/margin-top: 20%; }
   input.error{background: rgb(251, 227, 228);border: 1px solid #fbc2c4;color: #8a1f11;}
   #wrapper,.content-page{
   overflow:unset;
   }
</style>
<div class="">
   <!-- container -->
   <!-- <div class="row">
      <div class="col-sm-12">
      <div class="btn-group pull-right m-t-15">
      </div>
      <!--h4 class="page-title"> <?= Html::encode($this->title) ?></h4-->
   <!--ol class="breadcrumb">
      <li><a href="<?php echo Yii::$app->request->BaseUrl;?>">Home</a></li>
      <li><a href="#"><?php echo $this->title;?></a></li>
      <a class='btn btn-primary' style="float: right;" title="Stock Grid Table" href="<?php echo Yii::$app->homeUrl . "?r=stockmaster/index";?>">Grid</a>	
      
      	<a class='btn btn-primary' style="float: right;" title="Add Product Group" href="<?php echo Yii::$app->homeUrl . "?r=productgrouping/create";?>">Group</a>	
      </ol 
      </div>  
      </div>  -->
   <div id="load"  align="center"><img src="<?= Url::to('@web/dmc2.gif') ?>" />Loading...</div>
   <div class="row" >
      <div class="">
         <!-- col-sm-12 -->
         <div class="">
            <!-- panel panel-border panel-custom -->
            <!-- <div class="panel-heading">
               </div> -->
            <div class="">
               <!-- .panel-body -->
               <?php $form = ActiveForm::begin([
                  'id'=>'addnewstock', 
                        'action' => ['newstock'],
                        'method' => 'post',
                  'options' => ['class' => 'form-inline'             ]
                        
                    ]); 
                   		$session = Yii::$app->session;
                  $role=$session['authUserRole'];
                  $companybranchid=$session['branch_id'];
                  
                  ?>
               <div class="col-sm-11">
                  <div class="row">
                     <div class="col-sm-3">
                        <div class="panel pd-panel h-118">
                           <div class="panel-heading pd-panel-head">SUPPLIER DETAILS</div>
                           <div class="panel-body pd-panel-body">
                              <div class="row">
                                 <div class="   ">
                                    <label class="control-label col-sm-6 lbl-width">Supplier Name</label>
                                    <div class="input-group input-group-sm col-sm-6  ">	   			
                                       <input type="text" id=" " class="  ip-btn-style  f-11" name=" " required="" placeholder=" "> 								  		 					 
                                       <span class="ipt input-group-btn " value="click">
                                       <button type="button" class="btn inp btn-default"><i class="glyphicon glyphicon-search"></i></button>
                                       </span>   
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Address</label>
                                    <textarea class="col-sm-6 f-11" name="" id="" value=""></textarea>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Phone No</label>
                                    <input type="text" class="col-sm-6 h-20 f-11 " name="" id="" value="">
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="panel pd-panel h-118">
                           <div class="panel-heading pd-panel-head">INVOICE DETAILS</div>
                           <div class="panel-body pd-panel-body">
                              <div class="row">
                                 <div class="   ">
                                    <label class="control-label col-sm-6 lbl-width">Invoice No</label>
                                    <input type="text" class="col-sm-6 h-20 f-11" name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Invoice Date</label>
                                    <input type="text" class="col-sm-6 h-20 f-11" name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Credit Days</label>
                                    <input type="text" class="col-sm-6 h-20 f-11" name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Credit Date</label>
                                    <input type="text" class="col-sm-6 h-20 cdate f-11 " name="" id="" value="">
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="panel pd-panel ">
                           <div class="panel-body pd-panel-body">
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">DC No</label>
                                    <input type="text" class="col-sm-6  h-20 f-11" name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Security No</label>
                                    <input type="text" class="col-sm-6 h-20  f-11" name="" id="" value="">
                                 </div>
                              </div>
                           </div>
                           <div class="panel-heading pd-panel-head">GRN DETAILS</div>
                           <div class="panel-body pd-panel-body">
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Purchase Type:</label>                                    
									<select class="col-sm-6 h-20 f-11">
									  <option>PurOrder</option>
									  <option></option>
									  <option></option>
									</select>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Challan Type</label>
                                    <select class="col-sm-6 h-20 f-11">
									  <option>Direct</option>
									  <option></option>
									  <option></option>
									</select>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="panel pd-panel h-118">
                           <div class="panel-body pd-panel-body">
                              <div class="row">
                                 <div class="   ">
                                    <label class="control-label col-sm-6 lbl-width">PO No</label>
                                    <div class="input-group input-group-sm col-sm-6  ">	   			
                                       <input type="text" id=" " class="  ip-btn-style f-11 " name=" " required="" placeholder=" "> 								  		 					 
                                       <span class="ipt input-group-btn " value="click">
                                       <button type="button" class="btn inp btn-default"><i class="glyphicon glyphicon-search"></i></button>
                                       </span>   
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">Received By</label>
                                    <input type="text" class="col-sm-6 h-20 f-11 " name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                 <div class=" ">
                                    <label class="control-label col-sm-6 lbl-width">GRN No</label>
                                    <input type="text" class="col-sm-6 h-20 f-11" name="" id="" value="">
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class=" ">
                     <div class="panel pd-panel">
                        <div class="panel-heading pd-panel-head">ITEM GRID</div>
                        <div class="panel-body  pd-panel-body">
                           <table class="table table-bordered table-striped tbl-scrol thf-11" id="tbUser">
                              <thead>
                                 <tr>
                                    <th style="width:9%"></th>
                                    <th style="width:3%">SN</th>
                                    <th style="width:9%">Item_Name</th>
                                    <th>Qua</th>
                                    <th>Fre</th>
                                    <th>Pack</th>
                                    <th>Rate/pack</th>
                                    <th>Batch_No</th>
                                    <th>Exp_Date</th>
                                    <th>Dis..</th>
                                    <th>Dis..</th>
                                    <th>Tax%</th>
                                    <th>MR</th>
                                    <th>Amt</th>
                                    <th>Vat_On</th>
                                    <th><label class="checkbox-inline"><input type="checkbox" value="">Rate Q</label></th>
                                    <th>Item_Type</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <td style="width:9%" ><button type="button" class="btn btn-xs btn-success">Add</button>
                                    <button type="button" class="btn btn-xs btn-success">Del      </button>
                                 </td>
                                 <td style="width:3%"></td>
                                 <td style="width:9%">
                                    <div class="input-group input-group-sm   ">	   			
                                       <input type="text" id=" " class="  ip-btn-style f-11 " name=" " required="" placeholder=" "> 								  		 					 
                                       <span class="ipt input-group-btn " value="click">
                                       <button type="button" class="btn inp btn-default"><i class="glyphicon glyphicon-search"></i></button>
                                       </span>   
                                    </div>
                                 </td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                                 <td><label class="checkbox-inline"><input type="checkbox" value=""> 343</label></td>
                                 <td></td>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
                  <div class=" ">
                     <div class="col-sm-12">
                        <div class="panel pd-panel h-118">
                           <div class="panel-heading pd-panel-head">FINANCIAL  DETAILS</div>
                           <div class="panel-body pd-panel-body">
                              <div class="row">
                                 <div class="  col-sm-3 ">
                                    <label class="control-label col-sm-6 lbl-width">Total Amt</label>
                                    <input type="" class="col-sm-6 h-20 text-right" name="" id="" value="">
                                 </div>
								 <div class=" col-sm-3">
                                    <label class="control-label col-sm-6 lbl-width">Less Dicount</label>
                                    <input type=" " class="col-sm-6 h-20 text-right" name="" id="" value="">
                                 </div>
								 <div class="col-sm-3 ">
                                    <label class="control-label col-sm-6 lbl-width">Add Tax</label>
                                    <input type=" " class="col-sm-6 h-20 text-right" name="" id="" value="">
                                 </div>
								 <div class="col-sm-3 ">
                                    <label class="control-label col-sm-6 lbl-width">SCharge</label>
                                    <input type=" " class="col-sm-6 h-20 text-right" name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                   <div class=" col-sm-3  ">
                                    <label class="control-label col-sm-6 lbl-width">Add other Expense</label>
                                    <input type=" " class="col-sm-6 h-20 text-right" name="" id="" value="">
                                 </div>
								 <div class=" col-sm-3">
                                    <label class="control-label col-sm-6 lbl-width">Round Off</label>
                                    <input type=" " class="col-sm-6 h-20 text-right" name="" id="" value="">
                                 </div>
								 <div class=" col-sm-3">
                                    <label class="control-label col-sm-6 lbl-width">paid</label>
                                    <input type=" " class="col-sm-6 h-20 text-right" name="" id="" value="">
                                 </div>
								 <div class="col-sm-3 ">
                                    <label class="control-label col-sm-6 lbl-width">Net Amount</label>
                                    <input type=" " class="col-sm-6 h-20 text-right " name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                    <div class="col-sm-3 ">
                                    <label class="control-label col-sm-6 lbl-width">Balance</label>
                                    <input type="text" class="col-sm-6 h-20 text-right " name="" id="" value="">
                                 </div>
                              </div>
                              <div class="row">
                                 
                              </div>
                           </div>
                        </div>
                     </div>
                      
                  </div>
               </div>
               <div class="col-sm-1 ">
                  <div class="row">
                     <div class="form-group ">
                        <button type="button" class="btn btn-primary b1-width ">Save</button>
                     </div>
                  </div>
                  <br>
                  <div class="row">
                     <div class="form-group">
                        <button type="button" class="btn btn-primary b1-width ">Delete</button>
                     </div>
                  </div>
                  <br>
                  <div class="row">
                     <div class="form-group">
                        <button type="button" class="btn btn-primary b1-width ">Clear</button>
                     </div>
                  </div>
                  <br>
                  <div class="row">
                     <div class="form-group">
                        <button type="button" class="btn btn-primary b1-width ">Close</button>
                     </div>
                  </div>
                  <br>
                  <div class="row">
                     <div class="form-group">
                        <button type="button" class="btn btn-primary b1-width ">search</button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
 
</div>
<?php ActiveForm::end(); ?>
<div id="formdetails"></div>
</div>       
</div>
</div>
</div>
</div>
<script type="text/javascript" src="js/shortcut.js" ></script>
<script>
   $(document).ready(function(){
   	  $("#product_idz").selectpicker("refresh"); 
   $('body').on("click",'.addstock',function(){
   	$form_container=$("#addform");
     	 $form_container.validate().settings.ignore = ":disabled,:hidden";
     var chkform=$form_container.valid();
    if(chkform==true){
   $("#load").fadeIn("slow");
   var form = $("#addform");
   var formData = form.serialize();
   $.ajax({
          url: form.attr("action"),
          type: form.attr("method"),
          data: formData,
          success: function (data) {
          	$("#load").fadeOut("slow");
          	$("#formdetails").html(data);
          	$('[tabindex="1001"]').focus();
          	$("#formdetails").fadeIn("slow");
          	$(".demoz").selectpicker("refresh");
          	
          }
       });
      }
   
   });
   
   
   
   
   
   
   
   });
   
   
   
   
   $('body').on("click",'.save_stock',function(){
   	
   $form_container=$("#stock-form1");
     	 $form_container.validate().settings.ignore = ":disabled,:hidden";
     var chkform=$form_container.valid();
     if(chkform==true){
   //$("#load").fadeIn("slow");
    var form = $("#stock-form1");
    var formData = form.serialize();
    $.ajax({
          url: form.attr("action"),
          type: 'post',
          data: formData,
          success: function (data) {
          	$("#load").fadeOut("slow");
          	 noti();
   	     $("#formdetails").fadeOut("slow");
          }
         
       });	
   	}
   	function noti () {
    $.Notification.autoHideNotify('custom', 'top right', 'Stock Added successfully.');
   }	
   });
</script>
 
<script>
$(function () {
    $(".cdate").datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: '-120Y',
        maxDate: '-10Y',
        yearRange: '-120Y:-10Y',
        altField: "#txtDOBalt",
        altFormat: "yy-mm-dd",
        dateFormat: "dd-mm-yy",
		autoclose:true
    });
});
</script>