<?php

namespace backend\controllers;

use Yii;
use backend\models\Testgroup;
use backend\models\TestgroupSearch;
use backend\models\LabTesting;
use backend\models\LabTestgroup;
use backend\models\Taxgrouping;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
/**
 * TestgroupController implements the CRUD actions for Testgroup model.
 */
class TestgroupController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Testgroup models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new TestgroupSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
		
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Testgroup model.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
    	// echo"<pre>";
		 $testgroupname =Testgroup::find()->all();
		 $testname =LabTesting::find()->all();
		  
    	 $testgroup=LabTestgroup::find()->Where(['testgroupid'=>$id])->all();
		 
		 $grouplist=ArrayHelper::map($testgroup, 'autoid', 'testgroupid');
		 $grouplist1=ArrayHelper::map($testgroup, 'autoid', 'test_nameid');
		
		 $grouplist_det=LabTesting::find()->where(['IN','autoid',$grouplist])->all();
		 $grouplist_det_index=ArrayHelper::index($grouplist_det,'autoid');
		 
		 $testname_det=LabTesting::find()->where(['IN','autoid',$grouplist1])->all();
		 $testname_det_index=ArrayHelper::index($testname_det,'autoid');
		
		//  print_r($testname_det_index); die;
        return $this->renderAjax('view', [
            'model' => $this->findModel($id),
            'testname_det_index'=>$testname_det_index,
            'grouplist_det_index'=>$grouplist_det_index
        ]);
    }

    /**
     * Creates a new Testgroup model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Testgroup();
		
		$tax_grouping=ArrayHelper::map(Taxgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'taxgroupid', 'hsncode');
		
 		if(!empty($_POST)){
   	     // echo "<pre>"; print_r($_POST); die; 
   	       $model = new Testgroup();
		   $model->testgroupname=$_POST['Testgroup']['testgroupname'];
		   $model->isactive=$_POST['Testgroup']['isactive'];
		   if($model->save()){}else{
		   	//print_r($model->getErrors());die;
		   } 
		    if ($model->load(Yii::$app->request->post()) && $model->save()) {
	            return $this->redirect(['index', 'id' => $model->autoid]);
	        }
		}
        return $this->renderAjax('create', [
            'model' => $model,
            'tax_grouping'=>$tax_grouping,
			
        ]);
    }

 public function actionTestgroupmaster()
    {
        $model = new Testgroup();
		$model_group = new LabTestgroup();
		$searchModel = new TestgroupSearch();
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);
 
 		$testingmodel = new LabTesting();
		$testgrouplist=ArrayHelper::map(Testgroup::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'testgroupname');
 		$testlist=ArrayHelper::map(LabTesting::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'test_name');
		
		if(!empty($_POST)){
   			   			
		/*	$lab_count=count($_POST['hid_testname']);
			Yii::$app->db->createCommand()->delete('lab_testgroup', 'testgroupid = '.$_POST['TestgroupSearch']['testgroupname'])->execute();
				
			for($i=0;$i<$lab_count;$i++){
				
				$model_group= new LabTestgroup();
				$model_group->testgroupid=$_POST['TestgroupSearch']['testgroupname'];
				$model_group->test_nameid=$_POST['hid_testname'][$i];
				if($model_group->save()){} else {   //print_r($model_group->getErrors());die;
					}
			$model_test=LabTesting::find()->Where(['autoid'=>$_POST['hid_testname'][$i]])->one();
			$model_test->testgroupid=$_POST['TestgroupSearch']['testgroupname'];
			$model_test->save();
			
			}
    
	//echo "<pre>"; print_r($_POST); die;
   		 	$model1=Testgroup::find()->Where(['autoid'=>$_POST['TestgroupSearch']['testgroupname']])->one();
			if(!empty($_POST['hid_testname'])){
				$test_name=implode(",",$_POST['hid_testname']);	
			}
		  	$model1->testnameid=$test_name;
				if($model1->save()){} else {  //print_r($model->getErrors());
				  }
			
			
			
			
			return $this->redirect(['testgroupmaster']);*/
		}
else {
	

        return $this->render('testgroup', [
            'model' => $model,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'testingmodel' => $testingmodel,
            'testlist' =>$testlist,
            'testgrouplist' => $testgrouplist,
        ]);
}
		//return $this->render('_testform', ['model' => $searchModel,'testingmodel' => $testingmodel, 'testlist' => $testlist,'testgrouplist'=>$testgrouplist ]); 
		
    }

	

	
	
	
	public function actionAdd($id)
    {
    	$model = new Testgroup();
		$model_group = new LabTestgroup();
		$searchModel = new TestgroupSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
 
 		$testingmodel = new LabTesting();
		$testgrouplist=ArrayHelper::map(Testgroup::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'testgroupname');
 		$testlist=ArrayHelper::map(LabTesting::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'test_name');
		
		
		$test_list_tbl=  LabTesting::find()->where(['isactive'=>1])->asArray()->all();
		
		$group_list_tbl=LabTestgroup::find()->where(['testgroupid'=>$id])->asArray()->all();
		$array_index_key=ArrayHelper::index($group_list_tbl,'test_nameid');
		
		if($_POST)
		{
			
			if(!empty($_POST['Checked']))
			{
				LabTestgroup::deleteAll(['testgroupid'=>$id]);
				$data=array();
				$date_id=date('Y-m-d H:i:s');
				
				foreach ($_POST['Checked'] as $key => $value) 
				{
					$data[]=[$id,$value,$date_id];
				}
				$data_count=count($data);
				
				$status_count=Yii::$app->db->createCommand()->batchInsert('lab_testgroup', ['testgroupid','test_nameid', 'created_date'],$data)->execute();
				
				if($status_count == $data_count)
				{
					Yii::$app->getSession()->setFlash('success', 'Saved Successfully.');  
					return $this->redirect(['testgroupmaster']);
				}
				else
				{
					return $this->redirect(['testgroupmaster']);
					Yii::$app->getSession()->setFlash('error', 'Reference Table Not Insert Successfully');
				}
				
			}
		}
		else {
			return $this->render('_testform', ['array_index_key'=>$array_index_key,'test_list_tbl'=>$test_list_tbl,'model' => $searchModel,'testingmodel' => $testingmodel, 'testlist' => $testlist,'testgrouplist'=>$testgrouplist ]);
		}
	}
	
	
	public function actionAddcreate()
    {
    	$model = new Testgroup();
		$model_group = new LabTestgroup();
		$searchModel = new TestgroupSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
 
 		$testingmodel = new LabTesting();
		$testgrouplist=ArrayHelper::map(Testgroup::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'testgroupname');
 		$testlist=ArrayHelper::map(LabTesting::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'test_name');
		
		$test_list_tbl=LabTesting::find()->where(['isactive'=>1])->asArray()->all();
		
		if($_POST)
		{
			
			if(isset($_POST['Checked']))
			{
				
				$test_group_name=$_POST['TestgroupSearch']['testgroupname'];
			    $lab_testgroup=LabTestgroup::find()->where(['testgroupid'=>$test_group_name])->one();
				if(empty($lab_testgroup))
				{
					$data=array();
					$date_id=date('Y-m-d H:i:s');
					
					foreach ($_POST['Checked'] as $key => $value) 
					{
						$data[]=[$test_group_name,$value,$date_id];
					}
					$data_count=count($data);
					
					$status_count=Yii::$app->db->createCommand()->batchInsert('lab_testgroup', ['testgroupid','test_nameid', 'created_date'],$data)->execute();
					
					if($status_count == $data_count)
					{
						Yii::$app->getSession()->setFlash('success', 'Saved Successfully.');  
						return $this->redirect(['testgroupmaster']);
					}
					else
					{
						Yii::$app->getSession()->setFlash('error', 'Reference Table Not Insert Successfully');
						return $this->redirect(['testgroupmaster']);
					}
				}
				else 
				{
					Yii::$app->getSession()->setFlash('error', 'Group Name Already Exist');
					return $this->redirect(['testgroupmaster']);
				}
			}
			else
			{
					Yii::$app->getSession()->setFlash('error', 'Check Box Not Seleted! Data Not Inserting');		
					return $this->redirect(['testgroupmaster']);
			}
		}
		else {
			return $this->render('_testform2', ['test_list_tbl'=>$test_list_tbl,'model' => $searchModel,'testingmodel' => $testingmodel, 'testlist' => $testlist,'testgrouplist'=>$testgrouplist ]);
		}
	}
	
	

    /**
     * Updates an existing Testgroup model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    
	 
    public function actionUpdate($id)
    {
    	
		$model = $this->findModel($id);
 		$testgroupname =Testgroup::find()->all();
		$model_group = new LabTestgroup();
		$searchModel = new TestgroupSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
		$testname =LabTesting::find()->all();
		$testingmodel = new LabTesting();
		$testgrouplist=ArrayHelper::map(Testgroup::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'testgroupname');
 		$testlist=ArrayHelper::map(LabTesting::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'test_name');
		$tax_grouping=ArrayHelper::map(Taxgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'taxgroupid', 'hsncode');
		
		$resultgroup=Testgroup::find()->Where(['autoid'=>$id])->all();
		$model->autoid=$resultgroup[0]['autoid'];
		// $resultgroup_det=ArrayHelper::map($resultgroup_indec, 'autoid', 'autoid');
		// $resultgroup=ArrayHelper::index($resultgroup_det,'autoid');
		
		//echo "<pre>"; print_r($resultgroup_indec); die;
      
	   $testgroup=LabTestgroup::find()->Where(['testgroupid'=>$id])->all();
	   $grouplist=ArrayHelper::map($testgroup, 'autoid', 'testgroupid');
	   $grouplist1=ArrayHelper::map($testgroup, 'autoid', 'test_nameid');
		
		 $grouplist_det=LabTesting::find()->where(['IN','autoid',$grouplist])->all();
		 $grouplist_det_index=ArrayHelper::index($grouplist_det,'autoid');
		 
		 $testname_det=LabTesting::find()->where(['IN','autoid',$grouplist1])->all();
		 $testname_det_index=ArrayHelper::index($testname_det,'autoid');
		
		//echo "<pre>"; print_r($testname_det_index); die;
		
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index', 'id' => $model->autoid]);
        }

        return $this->renderAjax('update', [
            'model' => $model,
             'testname_det_index'=>$testname_det_index,
             '$grouplist_det_index'=>$grouplist_det_index,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'testingmodel' => $testingmodel,
            'testlist' =>$testlist,
            'testgrouplist' => $testgrouplist,
            'resultgroup' => $resultgroup,
              'tax_grouping'=>$tax_grouping,
        ]);
    }

 	public function actionUpdatemaster($id)
    {
    	
		$model = $this->findModel($id);
 		$testgroupname =Testgroup::find()->all();
		$model_group = new LabTestgroup();
		$searchModel = new TestgroupSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
		$testname =LabTesting::find()->all();
		$testingmodel = new LabTesting();
		$testgrouplist=ArrayHelper::map(Testgroup::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'testgroupname');
 		$testlist=ArrayHelper::map(LabTesting::find()->where(['isactive'=>1])->asArray()->all(), 'autoid', 'test_name');
		$tax_grouping=ArrayHelper::map(Taxgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'taxgroupid', 'hsncode');
		
		$resultgroup=Testgroup::find()->Where(['autoid'=>$id])->all();
		$model->autoid=$resultgroup[0]['autoid'];
		// $resultgroup_det=ArrayHelper::map($resultgroup_indec, 'autoid', 'autoid');
		// $resultgroup=ArrayHelper::index($resultgroup_det,'autoid');
		
		//echo "<pre>"; print_r($resultgroup_indec); die;
      
	   $testgroup=LabTestgroup::find()->Where(['testgroupid'=>$id])->all();
	   $grouplist=ArrayHelper::map($testgroup, 'autoid', 'testgroupid');
	   $grouplist1=ArrayHelper::map($testgroup, 'autoid', 'test_nameid');
		
		 $grouplist_det=LabTesting::find()->where(['IN','autoid',$grouplist])->all();
		 $grouplist_det_index=ArrayHelper::index($grouplist_det,'autoid');
		 
		 $testname_det=LabTesting::find()->where(['IN','autoid',$grouplist1])->all();
		 $testname_det_index=ArrayHelper::index($testname_det,'autoid');
		
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index', 'id' => $model->autoid]);
        }

        return $this->renderAjax('update', [
            'model' => $model,
             'testname_det_index'=>$testname_det_index,
             '$grouplist_det_index'=>$grouplist_det_index,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'testingmodel' => $testingmodel,
            'testlist' =>$testlist,
            'testgrouplist' => $testgrouplist,
            'resultgroup' => $resultgroup,
              'tax_grouping'=>$tax_grouping,
        ]);
    }    /**
     * Deletes an existing Testgroup model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Testgroup model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Testgroup the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Testgroup::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
