<?php

namespace backend\controllers;

use Yii;
use backend\models\Stockmaster;
use backend\models\Product;
use backend\models\Productgrouping;
use backend\models\StockmasterSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\models\Vendor;
use yii\helpers\ArrayHelper;
use yii\web\UploadedFile;
use yii\filters\AccessControl;
use backend\models\ServiceuserLogin;
use backend\models\AuthProjectModule;
use backend\models\CompanyBranch;
use backend\models\BranchAdmin;
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use backend\models\Producttype;
use backend\models\Composition;
use backend\models\Unit;
use backend\models\Stockrequest;
use backend\models\Stockresponse;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\VendorBranch;
use backend\models\Taxgrouping;
class StockmasterController extends Controller
{
    
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
                                  'access' => [
           'class' => AccessControl::className(),
           'rules' => [
               [
                   'allow' => true,
                   'roles' => ['@'],
               ],

             
           ],
       ],
        ];
    }


  public function beforeAction($action) {
          return BranchAdmin::checkbeforeaction();
	}
  
  
    public function actionIndex()
    {
    	
		
    	if($_POST){
    	
    	$Model = Stockmaster::find()->where(['stockid'=>$_POST['editableKey']])->one();
		if(count($Model)>0){
			//print_r($_POST);
			//die;
			$post = [];
			 $posted = current($_POST['Stockmaster']);
      $post['Stockmaster'] = $posted;
      if ($Model->load($post)) {
			//print_r($Model);
		  //die;
			$Model->priceperqty=($Model->price)/($Model->quantity);
			$Model->save();
			 $output = '';
            
           $out = Json_encode(['output'=>$output, 'message'=>'']); 
           }
		      echo $out;
		      return;
			
		}
		
	}
	
	
	else{
		$vendorlist=ArrayHelper::map(Vendor::find()->where(['is_active'=>1])->asArray()->all(), 'vendorid', 'vendorname');
		$productlist=ArrayHelper::map(Product::find()->where(['is_active'=>1])->asArray()->all(), 'productid', 'productname');
		 $branchlist=ArrayHelper::map(CompanyBranch::find()->where(['is_active'=>1])->asArray()->all(), 'branch_id', 'branch_name');
		$session = Yii::$app->session;
		$role=$session['authUserRole'];
		if($role=="Super")
		{
			$companylist=ArrayHelper::map(CompanyBranch::find()->where(['is_active'=>1])->asArray()->all(), 'branch_id', 'branch_name');
		}
		else{
			$companylist=[];
		}
		
		
		 $model = new Stockmaster();
		 
        $searchModel = new StockmasterSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'model' => $model,
            'vendorlist' => $vendorlist,
            'productlist'=>$productlist,
             'companylist'=>$companylist,
             'branchlist'=>$branchlist,
             
        ]);
	}
    }
   public function actionAudit()
    {
    	
		
    	if($_POST){
    	
    	$Model = Stockmaster::find()->where(['stockid'=>$_POST['editableKey']])->one();
		if(count($Model)>0){
			//print_r($_POST);
			//die;
			$post = [];
			 $posted = current($_POST['Stockmaster']);
      $post['Stockmaster'] = $posted;
      if ($Model->load($post)) {
			
			
			$Model->save();
			 $output = '';
            
           $out = Json_encode(['output'=>$output, 'message'=>'']); 
           }
		      echo $out;
		      return;
			
		}
		
	}
	
	
	else{
		
		
		 
		$vendorlist=ArrayHelper::map(Vendor::find()->where(['is_active'=>1])->asArray()->all(), 'vendorid', 'vendorname');
		$productlist=ArrayHelper::map(Product::find()->where(['is_active'=>1])->asArray()->all(), 'productid', 'productname');
		$producttypelist=ArrayHelper::map(Producttype::find()->where(['is_active'=>1])->asArray()->all(), 'product_typeid', 'product_type');
		$compositionlist=ArrayHelper::map(Composition::find()->where(['is_active'=>1])->asArray()->all(), 'composition_id', 'composition_name');
		$unitlist=ArrayHelper::map(Unit::find()->where(['is_active'=>1])->asArray()->all(), 'unitid', 'unitvalue');
		$stockcodelist=ArrayHelper::map(Productgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'productgroupid', 'stock_code');
		
		
		
		 $model = new Stockmaster();
        $searchModel = new StockmasterSearch();
       $dataProvider = $searchModel->auditsearch(Yii::$app->request->queryParams);
	   
	   
	   $branchlist=ArrayHelper::map(CompanyBranch::find()->where(['is_active'=>1])->asArray()->all(), 'branch_id', 'branch_name');
	    $productgrouplist=ArrayHelper::map(Productgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'productgroupid', 'brandcode');
        return $this->render('audit', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider, 'model' => $model, 'vendorlist' => $vendorlist, 'productlist'=>$productlist,'branchlist'=>$branchlist,
             'productgrouplist'=>$productgrouplist,'producttypelist'=>$producttypelist,'compositionlist'=>$compositionlist,'unitlist'=>$unitlist,
             'stockcodelist'=>$stockcodelist,
           
           
            
           
        ]);
	}
    }

   public function actionStockindex()
    {
    	
		$vendorlist=ArrayHelper::map(Vendor::find()->where(['is_active'=>1])->asArray()->all(), 'vendorid', 'vendorname');
		$productlist=ArrayHelper::map(Product::find()->where(['is_active'=>1])->asArray()->all(), 'productid', 'productname');
		$producttypelist=ArrayHelper::map(Producttype::find()->where(['is_active'=>1])->asArray()->all(), 'product_typeid', 'product_type');
		$compositionlist=ArrayHelper::map(Composition::find()->where(['is_active'=>1])->asArray()->all(), 'composition_id', 'composition_name');
		$unitlist=ArrayHelper::map(Unit::find()->where(['is_active'=>1])->asArray()->all(), 'unitid', 'unitvalue');
		$stockcodelist=ArrayHelper::map(Productgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'productgroupid', 'stock_code');
		  
	   $branchlist=ArrayHelper::map(CompanyBranch::find()->where(['is_active'=>1])->asArray()->all(), 'branch_id', 'branch_name');
	    $productgrouplist=ArrayHelper::map(Productgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'productgroupid', 'brandcode');
		
		$session = Yii::$app->session;
		$role=$session['authUserRole'];
		if($role=="Super")
		{
			$companylist=ArrayHelper::map(CompanyBranch::find()->where(['is_active'=>1])->asArray()->all(), 'branch_id', 'branch_name');
		}
		else{
			$companylist=[];
		}
		
		
		 $model = new Stockmaster();
		 
        $searchModel = new StockmasterSearch();
        $dataProvider = $searchModel->stocksearch(Yii::$app->request->queryParams);

        return $this->render('stockindex', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'model' => $model,
           'vendorlist' => $vendorlist, 'productlist'=>$productlist,'branchlist'=>$branchlist,
             'productgrouplist'=>$productgrouplist,'producttypelist'=>$producttypelist,'compositionlist'=>$compositionlist,'unitlist'=>$unitlist,
             'stockcodelist'=>$stockcodelist,
             
        ]);		
    	
    	
    }


    public function actionView($id)
    {
        return $this->renderAjax('view', [
            'model' => $this->findModel($id),
        ]);
    }

    public function actionCreate()
    {
        $model = new Stockmaster();
        if ($model->load(Yii::$app->request->post())) 
        {
        	$vendor=Yii::$app->request->post('Stockmaster')['vendorid'];
			$branch=Yii::$app->request->post('Stockmaster')['branch_id'];
			$product=Yii::$app->request->post('Stockmaster')['productid'];
			 $session = Yii::$app->session;
			 $userid=$session['user_id'];
			foreach ($product as  $value) 
			{
				
				$stockmaster=Stockmaster::find()->where(['vendorid'=>$vendor])->andwhere(['productid'=>$value])->andwhere(['branch_id'=>$branch])->one();
				$productgrp=Productgrouping::find()->where(['vendorid'=>$vendor])->andwhere(['productid'=>$value])->one();
				$pgrp=$productgrp->productgroupid;
				//echo $pgrp;die;
				if(count($stockmaster)>0){}
				else{
				
				     $maxid=Stockmaster::find()->max('stockid');
					
				  $stockdataarray[]=[ 'serialnumber'=>$maxid+1,
									  'branch_id'=>$branch,
									  'productgroupid'=>$pgrp,
									 'vendorid'=>$vendor,
									  'productid'=>$value, 
									  'is_active'=>1,
									  'updated_by'=>$userid,
									  'updated_ipaddress'=>$_SERVER['REMOTE_ADDR'],
									  'updated_on'=>date("Y-m-d H:i:s"),
					 ];
					  
					   $stockarray=['serialnumber','branch_id','productgroupid','vendorid','productid','is_active','updated_by','updated_ipaddress','updated_on'];
                       $insertCount1 = Yii::$app->db->createCommand()->batchInsert('stockmaster', $stockarray, $stockdataarray)->execute();
	                   $stockdataarray=[];
	    	       }
			
			}
			if($insertCount1){
				 Yii::$app->getSession()->setFlash('success','Stock Added successfully');
                return $this->redirect(['index']);
             }
			else{
				 Yii::$app->getSession()->setFlash('success','Stock not saved');
				 return $this->redirect(['index']);
			}
			
			
			
        } 
        
        
        
        else {
        	
        	$session = Yii::$app->session;
		$role=$session['authUserRole'];
		if($role=="Super")
		{
			$companylist=ArrayHelper::map(CompanyBranch::find()->where(['is_active'=>1])->asArray()->all(), 'branch_id', 'branch_name');
		}
		else{
			$companylist=[];
		}
        $vendorlist=ArrayHelper::map(Vendor::find()->where(['is_active'=>1])->asArray()->all(), 'vendorid', 'vendorname');
		 $vendorbranchlist=ArrayHelper::map(VendorBranch::find()->where(['is_active'=>1])->asArray()->all(), 'vendor_branchid', 'branchname');
		
            return $this->render('_createform', [
                'model' => $model,
                'list'=>$vendorlist,
                'companylist'=>$companylist,
                'vendorbranchlist'=>$vendorbranchlist,
            ]);
        }
    }

    /**
     * Updates an existing Stockmaster model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) ) {
            
		
			
		    $session = Yii::$app->session;
			
	        $model->updated_by=$session['user_id'];
			$model->updated_ipaddress=$_SERVER['REMOTE_ADDR'];
			$model->updated_on=date("Y-m-d H:i:s");
			
		
			if($model->save())
			{
				echo "Y";
			}
			else{
				echo "N";
			}
			
			
			
			
        }
		 else {
        	$vendorlist=ArrayHelper::map(Vendor::find()->where(['is_active'=>1])->asArray()->all(), 'vendorid', 'vendorname');
			$productlist=$this->getproductz($model->vendorid,$model->productid);
			
			//print_r($productdetail);
			//die;
			//$productlist=ArrayHelper::map(Product::find()->where(['is_active'=>1])->andwhere(['!=','productid',$productdetail])->asArray()->all(), 'productid', 'productname');
			
            return $this->renderAjax('update', [
                'model' => $model,
                'vendorlist'=>$vendorlist,
                'productlist'=>$productlist,
            ]);
        }
    }

    /**
     * Deletes an existing Stockmaster model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
	
	
	 public function actionGetproduct($id,$branchid)
    {
		 $rows = Productgrouping::find()->where(['vendorid' => $id])->andwhere(['is_active'=>1])->all();
		  $checkproduct = Stockmaster::find()->where(['vendorid' => $id])->andwhere(['is_active'=>1])->andwhere(['branch_id'=>$branchid])->all();
		  if(count($checkproduct)>0){
		  $prdouctdetail="";
		  foreach ($checkproduct as $key => $value) {
		  	 $productdetail[]=$value->productid;
		  }
		  }else{
		  	
		  	 $productdetail=[''];
		  }
		//echo "<pre>";
		 $data=Vendor::find()->where(['vendorid'=>$id])->one();
		
		if($data->default_vendor == 1)
		{
			$rows1 = Product::find()->where(['is_active' => 1])->all();
			if(!empty($rows1))
			{
				foreach ($rows1 as $key => $value) {
					 echo "<option value='$value->productid'>$value->productname</option>";
				}
			}
		}
		else {
				if(count($rows)>0){
            foreach($rows as $row){
            	
            	if(!(in_array($row->productid,  $productdetail))){
            	
				 $rows1 = Product::find()->where(['productid' => $row->productid])->one();
					if($rows1->productid!=""){
                echo "<option value='$rows1->productid'>$rows1->productname</option>";
				}
				}
			}
        }	
		}
        
       
		
	}
	
	
	public function actionGetvendorbranch($vendorid)
    {
		 $rows = VendorBranch::find()->where(['vendorid' => $vendorid])->andwhere(['is_active'=>1])->all();
		 
        if($rows){
            foreach($rows as $row){
            	
            	
                echo "<option value='$row->vendor_branchid'>$row->branchname</option>";
				
			}
        }
       
		
	}
	
	
	 public function actionGetvendor($id)
    {
		 $rows = VendorBranch::find()->where(['vendor_branchid' => $id])->andwhere(['is_active'=>1])->one();
		 
	
        if(count($rows)>0){
          
            	      $vendordata=Vendor::find()->where(['vendorid'=>$rows->vendorid])->one();
					  $vendorname=$vendordata->vendorname;
                        echo "<option value='$rows->vendorid'>$vendorname</option>";
				
				}
			
       
		
	}

	
	 public function Getproductz($id,$pro)
    {
    	
		 $rows = Productgrouping::find()->where(['vendorid' => $id])->andwhere(['is_active'=>1])->all();
		 $checkproduct = Stockmaster::find()->where(['vendorid' => $id])->andwhere(['!=','productid',$pro])->andwhere(['is_active'=>1])->all();
		  if(count($checkproduct)>0)
		   {
		      $prdouctdetail="";
		      foreach ($checkproduct as $key => $value)
			   {
		  	  $productdetail[]=$value->productid;
			   }
		  }else{
		  	
		  	 $productdetail=[''];
		    }
	$val=[];
            if(count($rows)>0){
            foreach($rows as $row){
            if(!(in_array($row->productid,  $productdetail))){
            $rows1 = Product::find()->where(['productid' => $row->productid])->one();
			if($rows1->productid!=""){
             $val[$rows1->productid]=$rows1->productname;
				}
				}else
				{
			 }
			}
        }
        else{
          // echo "<option>Product Not Available for this Vendor.</option>";
        }
		return $val;
	}

    /**
     * Finds the Stockmaster model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Stockmaster the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Stockmaster::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
	
	public function actionExcelexport() {
	
		$objPHPExcel = new \PHPExcel();

		$sheet = 0;

		$objPHPExcel -> setActiveSheetIndex($sheet);
		
	
		$all_post_key = array("Sl. No.","branch_id","productname","vendorid","brandcode", "quantity","price");
		
		$r=0;
		$objPHPExcel -> getActiveSheet() -> setTitle("Stock_Details")				  
		-> setCellValue('A1', $all_post_key[$r]) 
		-> setCellValue('B1', $all_post_key[$r+1]) 
		-> setCellValue('C1', $all_post_key[$r+2])
		-> setCellValue('D1', $all_post_key[$r+3])
		-> setCellValue('E1', $all_post_key[$r+4])
		-> setCellValue('F1', $all_post_key[$r+5])
		-> setCellValue('G1', $all_post_key[$r+6]);
		
		
		$un_send_data = Stockmaster::find()-> all();
		
		
		$row = 2;
		$slno=1;			
		foreach($un_send_data as $one_data){
			$r_a=65;$r_a1=64;			
			foreach($all_post_key as $one_field){
				$cell_char=chr($r_a);
				if($r_a1>=65){
					$cell_char=chr($r_a1).chr($r_a);
				}
				if($one_field=='Sl. No.'){
					
					$objPHPExcel -> getActiveSheet() -> setCellValue($cell_char . $row, $slno);
				}else{
					
				if($one_field=="branch_id")
					{
						
						$id=$one_data->$one_field;
						$branchdata = CompanyBranch::find()->where(["branch_id"=>$id])->one();
			            $code=$branchdata->branch_code;
			 	   $objPHPExcel -> getActiveSheet() -> setCellValue($cell_char . $row, $code);
			     }
					
				else if($one_field=="productname")
					{
						//echo '<pre>';
						//print_r($one_field);die;
						$id=$one_data['productid'];
						
						$productdata = Product::find()->where(["productid"=>$id])->one();
						//print_r($productdata->stock_code);die;
						if(!empty($productdata->productname))
						{
							$code=$productdata->productname;	
						}
						else {
							$code='';
						}
			            
			 	   $objPHPExcel -> getActiveSheet() -> setCellValue($cell_char . $row, $code);
			     }
					else if($one_field=="vendorid")
					{
						
						$id=$one_data->$one_field;
						$vendordata = Vendor::find()->where(["vendorid"=>$id])->one();
			            $code=$vendordata->vendorcode;
			 	   $objPHPExcel -> getActiveSheet() -> setCellValue($cell_char . $row, $code);
			        }
					else{
						$objPHPExcel -> getActiveSheet() -> setCellValue($cell_char . $row, $one_data->$one_field);
					}
					
					
				}
				if($r_a>=90){
					$r_a=64;
					$r_a1++;					
				}
				$r_a++;
			}
			$slno++;			
			$row++;
		}
 $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');

		header('Content-Type: application/vnd.ms-excel');
        $filename = "Stock List Details_".date("d-m-Y-His").".xls";
        header('Content-Disposition: attachment;filename='.$filename .' ');
        header('Cache-Control: max-age=0');		
		 $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');  
			die; 
		
		
}







public function actionExcelimport()
    {
    	
    	$model=new Stockmaster();
		
    	 return $this->render('uploadformexl', [ 'model' => $model]);
       
	}
	
	
	 public function actionAddstock()
    {
    	
	  $model = new Stockmaster();	
	  $vendorid=Yii::$app->request->post('Stockmaster')['vendorid'];
	   $products=Yii::$app->request->post('Stockmaster')['productid'];
	   $branch=Yii::$app->request->post('Stockmaster')['branch_id'];
	   
		
	if( $vendorid!="" &&  $products!=""){
          return $this->renderAjax('stockproduct', [ 'model' => $model,'vendorid'=>$vendorid,'products'=>$products,'branch'=>$branch]);
	}
	else{
		 return $this->redirect(['index']);
	}
	
	}
	 public function actionSavestock()
    {
    	  
            $productid=Yii::$app->request->post('Stockmaster')['productid'];
            $vendor=Yii::$app->request->post('Stockmaster')['vendorid'];
			$branch=Yii::$app->request->post('Stockmaster')['branch_id'];
			$vendor_branchid=Yii::$app->request->post('Stockmaster')['vendor_branchid'];
			$stockrequestdata=	Stockrequest::find()->orderBy(['requestid' => SORT_DESC])->one();
			$stockincrement=$stockrequestdata->requestincrement+1;
			
			
    	    if($productid!=""){
    	    $i=1;
			foreach ($productid as $key => $value) {
			$stock=new Stockmaster();
		    $stock->serialnumber=Stockmaster::find()->orderBy(['stockid' => SORT_DESC])->one()+1;
			$stock->branch_id=$branch;
			$stock->vendor_branchid=$vendor_branchid;
			$stock->productgroupid=Yii::$app->request->post('productgroupid'.$i);
			$stock->productid=$value;
			$stock->vendorid=$vendor;
			$stock->compositionid=Yii::$app->request->post('compositionid'.$i);
			$stock->unitid=Yii::$app->request->post('Stockresponse')["unitid"][$key];
			$stock->brandcode=Yii::$app->request->post('brandcode'.$i);
			$stock->stockcode=Yii::$app->request->post('stockcode'.$i);
			$stock->unitquantity=Yii::$app->request->post('unitquantity'.$i);
			
			
			
			
			
			$stock->batchnumber=Yii::$app->request->post('batchnumber'.$i);
			$stock->manufacturedate=date("Y-m-d",strtotime(Yii::$app->request->post('manufacturedate'.$i)));
			$stock->expiredate=date("Y-m-d",strtotime(Yii::$app->request->post('expiredate'.$i)));
			$stock->quantity=Yii::$app->request->post('quantity'.$i);
			$stock->total_no_of_quantity=Yii::$app->request->post('totalunits'.$i);
			$stock->priceperqty=Yii::$app->request->post('Stockresponse')["priceperquantity"][$key];
			$stock->price=Yii::$app->request->post('Stockresponse')["purchaseprice"][$key];
		    $stock->is_active=1;
			$session = Yii::$app->session;
		    $stock->updated_by=$session['user_id'];
		    $stock->updated_ipaddress=$_SERVER['REMOTE_ADDR'];
			$stock->updated_on=date("Y-m-d H:i:s");
			
			if($stock->save())
			{
			$stockrequest = new Stockrequest();
			$stockrequest->requestincrement=$stockincrement;
			$vendorid=$stock->vendorid;
			$vendordata=Vendor::find()->where(['vendorid'=>$vendorid])->one();
			$vendorcode=$vendordata->vendorcode;
			$stockrequest->requestcode="DS/".$vendorcode."/".date("Y")."/".date('m')."/".($stockincrement);
			$stockrequest->requesttype="directstock";
			$stockrequest->branch_id=$stock->branch_id;
			$stockrequest->vendorid=$stock->vendorid;
			$stockrequest->productid=$stock->productid;
			$stockrequest->brandcode=$stock->brandcode;
			$stockrequest->quantity=$stock->quantity;
			$stockrequest->unitid=$stock->unitid;
			$stockrequest->total_no_of_quantity=$stock->total_no_of_quantity;
			$stockrequest->requestdate=date("Y-m-d");
			$stockrequest->is_active=1;
			$session = Yii::$app->session;
			$stockrequest->updated_by=$session['user_id'];
			$stockrequest->updated_ipaddress=$_SERVER['REMOTE_ADDR'];
			$stockrequest->updated_on=date("Y-m-d H:i:s");	
			$stockrequest->productgroupid=$stock->productgroupid;
			if($stockrequest->save())
			{
			 	    $model=new Stockresponse();	
			 		$session = Yii::$app->session;
					$model->stockrequestid=$stockrequest->requestid;
					$model->request_code=$stockrequest->requestcode;
					$model->stockid=$stock->stockid;
					$model->branch_id=$stockrequest->branch_id;
					$model->batchnumber=Yii::$app->request->post('batchnumber'.$i);
					$model->receivedquantity=$stockrequest->quantity;
					$model->total_no_of_quantity=$stockrequest->total_no_of_quantity;
					$model->unitid=$stockrequest->unitid;
					
					$model->purchaseprice=$stock->price;
					$model->priceperquantity=$stock->priceperqty;
			        $expiredate=Yii::$app->request->post('expiredate'.$i);
			        $model->expiredate=date("Y-m-d",strtotime($expiredate));
			        $model->purchasedate=date("Y-m-d",strtotime(Yii::$app->request->post('Stockresponse')["purchaseprice"][$key]));
			        $manufacturedate=Yii::$app->request->post('manufacturedate'.$i);
			        $model->manufacturedate=date("Y-m-d",strtotime($manufacturedate));
			        $model->updated_by=$session['user_id'];
			        $model->updated_ipaddress=$_SERVER['REMOTE_ADDR'];
			        $model->updated_on=date("Y-m-d H:i:s");
					$model->receivedfreequantity=0;
					$model->discountpercent=Yii::$app->request->post('Stockresponse')["discountpercent"][$key];
					$model->discountvalue=Yii::$app->request->post('Stockresponse')["discountvalue"][$key];
				
					
				
					$model->gstpercent=Yii::$app->request->post('Stockresponse')["gstpercent"][$key];
					$model->gstvalue=Yii::$app->request->post('Stockresponse')["gstvalue"][$key];
					$model->cgstpercent=Yii::$app->request->post('Stockresponse')["cgstpercent"][$key];
					$model->cgstvalue=Yii::$app->request->post('Stockresponse')["cgstvalue"][$key];
					$model->sgstpercent=Yii::$app->request->post('Stockresponse')["sgstpercent"][$key];
					$model->sgstvalue=Yii::$app->request->post('Stockresponse')["sgstvalue"][$key];
					$model->igstpercent=Yii::$app->request->post('Stockresponse')["igstpercent"][$key];
					$model->igstvalue=Yii::$app->request->post('Stockresponse')["igstvalue"][$key];
					$model->mrpperunit=Yii::$app->request->post('Stockresponse')["mrpperunit"][$key];
					$model->mrp=Yii::$app->request->post('Stockresponse')["mrp"][$key];
					$model->save();
				
			 }
			  }
            else
				{
					print_r($stock->getErrors());die;
				}
					   ++$i;
    	}
	}

else {
	      echo "product is invalid";
     }


	}
	
	
	public function actionExcelupload(){
		$model=new Stockmaster();
	    if (Yii::$app->request->isPost) {
		$model -> brandcode = UploadedFile::getInstance($model, 'brandcode');
			$data_name=$model -> brandcode -> tempName;	
			$objPHPExcel = \PHPExcel_IOFactory::load($data_name);
			$sheetData = $objPHPExcel -> getActiveSheet() -> toArray(null, true, true, true);
			$sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
         for($row=2; $row<=$highestRow; ++$row)
         {                  
             $model = new Stockmaster;
             $rowData = $sheet->rangeToArray('A'.$row.':'.$highestColumn.$row,NULL,TRUE,FALSE);
             $stockcode = $rowData[0][1];
             $vendorcode= $rowData[0][2];
			 $vendordata = Vendor::find()->where(['LIKE',"vendorcode",$vendorcode])->one();
			 $query=Stockmaster::find()  ->where(['stockid' => Stockmaster::find()->max('stockid')]) ->one();
                    $sno=$query->stockid+1;
			 if(!empty($vendordata))
			 {
			 	$model->vendorid=$vendordata->vendorid;
			 }
			 else{
			 	$model->vendorid="";
			 }
			  $productdata = Product::find()->where(['LIKE',"stock_code",$stockcode])->one();
			 if(!empty($productdata))
			 {
			 	$model->productid=$productdata->productid;
			 }
			 else{
			 	$model->productid="";
			 }
		     $model->brandcode = $rowData[0][3];
			 $model->quantity = $rowData[0][4];
			 $model->price = $rowData[0][5];
			 $model->is_active=$rowData[0][6];
		     $session = Yii::$app->session;
	         $model->updated_by=$session['user_id'];
			 $model->updated_ipaddress=$_SERVER['REMOTE_ADDR'];
			 $model->updated_on=date("Y-m-d H:i:s");
			 $model->serialnumber=$sno;
			 $model->save();
			
         }
		  return $this->redirect(['index']);
	}
	}
	
	
		public function actionExportexceldownload($productid,$vendorid,$compositionid,$brandcode,$stockcode,$expfrom,$expto,$branchid)
		 {
		$objPHPExcel = new \PHPExcel();
		$sheet = 0;
		$objPHPExcel -> setActiveSheetIndex($sheet);
	    $vendorlist=ArrayHelper::map(Vendor::find()->where(['is_active'=>1])->asArray()->all(), 'vendorid', 'vendorname');
		$productlist=ArrayHelper::map(Product::find()->where(['is_active'=>1])->asArray()->all(), 'productid', 'productname');
		$producttypelist=ArrayHelper::map(Producttype::find()->where(['is_active'=>1])->asArray()->all(), 'product_typeid', 'product_type');
		$compositionlist=ArrayHelper::map(Composition::find()->where(['is_active'=>1])->asArray()->all(), 'composition_id', 'composition_name');
		$unitlist=ArrayHelper::map(Unit::find()->where(['is_active'=>1])->asArray()->all(), 'unitid', 'unitvalue');
		$stockcodelist=ArrayHelper::map(Productgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'productgroupid', 'stock_code');
	    $branchlist=ArrayHelper::map(CompanyBranch::find()->where(['is_active'=>1])->asArray()->all(), 'branch_id', 'branch_name');
		$session = Yii::$app->session;
		$role=$session['authUserRole'];
		$companybranchid=$session['branch_id'];
		$query = Stockmaster::find()->joinwith(['stockresponse']);
		 
		 
		if(!empty($branchid))
		{
			$query->andFilterWhere(['stockresponse.branch_id' =>$branchid]);
		}
		
		if(!empty($productid))
		{
			 $query->andFilterWhere(['productid'=> $productid]);
		}
        if(!empty($vendorid))
		{
			 $query->andFilterWhere(['vendorid'=> $vendorid]);
		}
		if(!empty($compositionid))
		{
			 $query->andFilterWhere(['compositionid'=> $compositionid]);
		}
		if(!empty($brandcode))
		{
			 $query->andFilterWhere(['brandcode'=> $brandcode]);
		}
		if(!empty($stockcode))
		{
			 $query->andFilterWhere(['stockcode'=> $stockcode]);
		}
		
		
		 if(!empty($expdate))
	{
		
	  $fromdate=date("Y-m-d",strtotime($expfrom));
	  $todate=date("Y-m-d",strtotime($expto));
	   $query->andFilterWhere(['between', 'stockresponse.expiredate',$fromdate, $todate]);
	}
	
	
		 $dataProvider = new ActiveDataProvider(['query' => $query ]);
         $datatables = $dataProvider->getModels();
						$objPHPExcel -> getActiveSheet() -> setTitle("Stock_Details")				  
		-> setCellValue('A1', "Serial No") 
		-> setCellValue('B1', "Serial No") 
		-> setCellValue('C1', "Vendor") 
		-> setCellValue('D1', "Stock")
		-> setCellValue('E1', "Stock Type")
		-> setCellValue('F1', "Stock Code")
		-> setCellValue('G1', "Drug")
		-> setCellValue('H1', "BrandCode")
		-> setCellValue('I1', "Batch Number")		
		-> setCellValue('J1', "Expire Date")
		-> setCellValue('K1', "Quantity")	
		-> setCellValue('L1', "Unit")-> setCellValue('M1', "Price\Qty")	-> setCellValue('N1', "Price");	
                                	if(count($datatables)>0){
                                		$i=1;
                                			$row = 2;
                                		
                                	foreach ($datatables as $key => $value) {
                                		$stockdata=Stockresponse::find()->where(['stockid'=>$value->stockid])->all();
												
								
										$vendorid=array();$productid=array();$productgroupid=array();$stockcodeid=array();$compositionid=array();$branchid=array();
										
										
										
										$branchid[]=$value->branch_id;
										$newbranchdata=array_intersect_key($branchlist, array_flip($branchid));
									    $branchval=array_values($newbranchdata);
										
										
										
										$vendorid[]=$value->vendorid;
										$newvendordata=array_intersect_key($vendorlist, array_flip($vendorid));
									    $vendorval=array_values($newvendordata);
										
										$productid[]=$value->productid;
										$newproductdata=array_intersect_key($productlist, array_flip($productid));
									    $productval=array_values($newproductdata);
										
										$pdata=Product::find()->where(['is_active'=>1])->andwhere(['productid'=>$value->productid])->one();
										
										$compositionid[]=$value->compositionid;
										$newcompositiondata=array_intersect_key($compositionlist, array_flip($compositionid));
									    $compositionval=array_values($newcompositiondata);
										
										$unitid[]=$value->unitid;
										$newunitdata=array_intersect_key($unitlist, array_flip($unitid));
									    $unitval=array_values($newunitdata);
										if($pdata)
										{
											
											$producttypeid[]=$pdata->product_typeid;
										$newproducttypedata=array_intersect_key($producttypelist, array_flip($producttypeid));
									    $producttypeval=array_values($newproducttypedata);
										}
										
										if($stockdata)
										{
														foreach($stockdata as $sd)
										{
											
									$r_a=65;
								   	$batchno=$sd->batchnumber;
										$expdate=date("d/m/Y",strtotime($sd->expiredate));
										$priceperqty=$sd->priceperquantity;
										$price=$sd->purchaseprice;
				
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr($r_a).$row, $i);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $branchval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $vendorval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $productval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $producttypeval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $value->stockcode);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $compositionval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $value->brandcode);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$batchno);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$expdate);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$sd->receivedquantity);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$unitval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$priceperqty);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$price);
			            $row++;	
						$i++;
                               } 
										}
										
										else{
												$r_a=65;
											$batchno="";
										$expdate="";
										$price="";$qty="";$priceperqty="";
										$objPHPExcel -> getActiveSheet() -> setCellValue(chr($r_a).$row, $i);
										$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $branchval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $vendorval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $productval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $producttypeval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $value->stockcode);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $compositionval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row, $value->brandcode);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$batchno);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$expdate);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$sd->receivedquantity);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$unitval[0]);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$priceperqty);
						$objPHPExcel -> getActiveSheet() -> setCellValue(chr(++$r_a) . $row,$price);
										
								  $row++;			
											
								 $i++;
											
										}
                                    $newbranchdata=array(); $branchid=array(); $branchval="";
								    $newvendordata=array();  $vendorid=array();  $vendorval="";
									$newproductdata=array(); $productid=array();$productval="";
									$newproductgroupdata=array(); $productgroupid=array();$productgroupval="";
									$newproducttypedata=array(); $producttypeid=array();$producttypeval="";
									$newcompositiondata=array(); $compositionid=array();$compositionval="";
									$newstockcodedata=array(); $stockcodeid=array();$unitval="";
									$newunitdata=array(); $unitid=array();$stockcodeval="";
									
									
									
                               }	} 
                                
                              

		
 $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');

		header('Content-Type: application/vnd.ms-excel');
        $filename = "Stock List Details_".date("d-m-Y-His").".xls";
        header('Content-Disposition: attachment;filename='.$filename .' ');
        header('Cache-Control: max-age=0');		
		 $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');  
		 return $this->redirect(['index']);
		
	}

		public function actionExportpdfdownload($productid,$vendorid,$compositionid,$brandcode,$stockcode,$expfrom,$expto,$branchid) 
		{
			
			require ('../../vendor/tcpdf/tcpdf.php');
	    $pdf = new \TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('Invoice');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

$pdf->setFontSubsetting(true);
$pdf->SetFont('helvetica', '', 8, '', true);
$pdf->AddPage();



	    $vendorlist=ArrayHelper::map(Vendor::find()->where(['is_active'=>1])->asArray()->all(), 'vendorid', 'vendorname');
		$productlist=ArrayHelper::map(Product::find()->where(['is_active'=>1])->asArray()->all(), 'productid', 'productname');
		$producttypelist=ArrayHelper::map(Producttype::find()->where(['is_active'=>1])->asArray()->all(), 'product_typeid', 'product_type');
		$compositionlist=ArrayHelper::map(Composition::find()->where(['is_active'=>1])->asArray()->all(), 'composition_id', 'composition_name');
		$unitlist=ArrayHelper::map(Unit::find()->where(['is_active'=>1])->asArray()->all(), 'unitid', 'unitvalue');
		$stockcodelist=ArrayHelper::map(Productgrouping::find()->where(['is_active'=>1])->asArray()->all(), 'productgroupid', 'stock_code');
	    $query = Stockmaster::find()->joinwith(['stockresponse']);
		$session = Yii::$app->session;
		$companybranchid=$session['branch_id'];
		$role=$session['authUserRole'];
		
		
	
		if(!empty($branchid))
		{
				
			$query->andFilterWhere(['stockresponse.branch_id' =>$branchid]);
			$branchdata=CompanyBranch::find()->where(['branch_id'=>$branchid])->one();
			$branchname=$branchdata->branch_name;
		}
		else{
			$branchname ="All Branches";
		}
		
		
		
		if(!empty($productid))
		{
			 $query->andFilterWhere(['productid'=> $productid]);
		}
        if(!empty($vendorid))
		{
			 $query->andFilterWhere(['vendorid'=> $vendorid]);
		}
		if(!empty($compositionid))
		{
			 $query->andFilterWhere(['compositionid'=> $compositionid]);
		}
		if(!empty($brandcode))
		{
			 $query->andFilterWhere(['brandcode'=> $brandcode]);
		}
		if(!empty($stockcode))
		{
			 $query->andFilterWhere(['stockcode'=> $stockcode]);
		}
 if(!empty($expdate))
	{
		
	  $fromdate=date("Y-m-d",strtotime($expfrom));
	  $todate=date("Y-m-d",strtotime($expto));
	  $query->andFilterWhere(['between', 'stockresponse.expiredate',$fromdate, $todate]);
	}
         $dataProvider = new ActiveDataProvider(['query' => $query,'pagination'=>false]);
         $datatables = $dataProvider->getModels();
          $tbl='<table  cellspacing="1" cellpadding="3" border="0.1">
                                <tr>
                                	<td ><b>#</b></td>
                                    <td><b>Vendor</b></td>
                                    <td><b>Stock</b></td>
                                    <td><b>Type</b></td>
                                    <td><b>Stock Code</b></td>
                                    <td><b>Drug</b></td>
                                    <td><b>Brand Code</b></td>
                                    <td><b>Batch Number</b></td>
                                    <td><b>Expire Date</b></td>
                                    <td ><b>Total Qty</b></td>
                                    <td ><b>Unit</b></td>
                                    <td><b>MRP/Unit<br>(Rs.)</b></td>
                                    <td><b>Price<br>(Rs.)</b></td>
                                </tr>
                              <tbody>';
						if(count($datatables)>0)
                                	{
                                		$i=1;
                                	foreach ($datatables as $key => $value) {
                                		$stockdata=Stockresponse::find()->where(['stockid'=>$value->stockid])->all();
										$vendorid=array();$productid=array();$productgroupid=array();$stockcodeid=array();$compositionid=array();$branchid=array();
										$vendorid[]=$value->vendorid;
										$newvendordata=array_intersect_key($vendorlist, array_flip($vendorid));
									    $vendorval=array_values($newvendordata);
										$productid[]=$value->productid;
										$newproductdata=array_intersect_key($productlist, array_flip($productid));
									    $productval=array_values($newproductdata);
										$pdata=Product::find()->where(['is_active'=>1])->andwhere(['productid'=>$value->productid])->one();
										$compositionid[]=$value->compositionid;
										$newcompositiondata=array_intersect_key($compositionlist, array_flip($compositionid));
									    $compositionval=array_values($newcompositiondata);
										$unitid[]=$value->unitid;
										$newunitdata=array_intersect_key($unitlist, array_flip($unitid));
									    $unitval=array_values($newunitdata);
										if($pdata)
										{
										$producttypeid[]=$pdata->product_typeid;
										$newproducttypedata=array_intersect_key($producttypelist, array_flip($producttypeid));
									    $producttypeval=array_values($newproducttypedata);
										}
										if($stockdata)
										{
										foreach($stockdata as $sd)
										{
											$batchno=$sd->batchnumber;
										$expdate=date("d/m/y",strtotime($sd->expiredate));
										$priceperqty=$sd->mrpperunit;
										$price=$sd->purchaseprice;
										
                                $tbl.= "<tr><td style='width:50px;'>".$i."</td> <td>".$vendorval[0]."</td> <td>".$productval[0]."</td>
                                   <td>".$producttypeval[0]."</td><td>".$value->stockcode."</td> <td>".$compositionval[0]."</td> <td>".$value->brandcode."</td>
                                   <td>".$batchno."</td>
                                  <td>".$expdate."</td>
								<td align='right;'>".$sd->total_no_of_quantity."</td>
								<td>".$unitval[0]."</td>
								<td align='right'>".$priceperqty."</td>
								<td align='right'>".$price."</td>
                               </tr>";
							   
							   
								 $i++;
                               } 
								}
								else
										{
										$batchno="";
										$expdate="";
										$price="";$qty="";
				                   	$tbl.= "<tr><td>".$i."</td>
									<td>".$vendorval[0]."</td> 
								    <td>".$productval[0]."</td>
                                    <td>".$producttypeval[0]."</td>
                                    <td>".$value->stockcode."</td> 
                                    <td>".$compositionval[0]."</td>
                                    <td>".$value->brandcode."</td>
                                    <td>".$batchno."</td><td>".$expdate."</td><td align='right'>".$qty."</td>
                                    <td>".$unitval[0]."</td><td align='right'></td><td align='right'></td>
                                 </tr>";
								 $i++;	
										}
								    $newvendordata=array();  $vendorid=array();  $vendorval="";
									$newproductdata=array(); $productid=array();$productval="";
									$newproductgroupdata=array(); $productgroupid=array();$productgroupval="";
									$newproducttypedata=array(); $producttypeid=array();$producttypeval="";
									$newcompositiondata=array(); $compositionid=array();$compositionval="";
									$newstockcodedata=array(); $stockcodeid=array();$unitval="";
									$newunitdata=array(); $unitid=array();$stockcodeval="";
                               }	
                               } 
                          $tbl.='</tbody></table>';
                          $header="<center><h2 style='text-align:center;'> $branchname - Stocklist</h2><center>";
                          $pdf->writeHTML($header, true, false, false, false, '');
	                      $pdf->writeHTML($tbl, true, false, false, false, '');
                          $pdf->Output('example_001.pdf');
                          
	}

		 public function actionGetunitquantity($id,$dataid)
    {
    	
		$rows=Unit::find()->where(['unitid'=>$id])->one();
		$res["noofunit"]=$rows->no_of_unit;
		$res["dataid"]=$dataid;
        return json_encode($res);
		
	}
	
	public function actionGetigstcalculation($id,$dataid)
    {
    	
		$rows=VendorBranch::find()->where(['vendor_branchid'=>$id])->one();
		$res["igstpercent"]=$rows->igstpercent;
		$res["dataid"]=$dataid;
        return json_encode($res);
		
		
	}
	
	
	
}