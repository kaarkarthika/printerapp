<?php

namespace backend\controllers;

use Yii;
use backend\models\CancelLogTable;
use backend\models\CancelLogTableSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\models\Newpatient;
use backend\models\SubVisit;
use backend\models\BranchAdmin;
use backend\models\Physicianmaster;
use backend\models\Specialistdoctor;
use backend\models\PaymentType;
use backend\models\Patienttype;
use backend\models\Ucil;
use backend\models\ConsultantAmt;
use yii\helpers\ArrayHelper;
use backend\models\Insurance;
use backend\models\AutoidTable;
/**
 * CancelLogTableController implements the CRUD actions for CancelLogTable model.
 */
class CancelLogTableController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all CancelLogTable models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new CancelLogTableSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single CancelLogTable model.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new CancelLogTable model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new CancelLogTable();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->cancel_id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing CancelLogTable model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->cancel_id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing CancelLogTable model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the CancelLogTable model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return CancelLogTable the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = CancelLogTable::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
	
	//Refund Cancel Type
	public function actionCancelopd()
	{
		$newpatient=new Newpatient();
		$subvisit=new SubVisit();
		$cancellog=new CancelLogTable();
		
		if($_POST)
		{
			$session = Yii::$app->session;
			$role=$session['authUserRole'];
			$companybranchid=$session['branch_id'];  
			
			$auto_get_cancel=AutoidTable::find()->where(['auto'=>5])->asArray()->one();
			$inc_value_sub=$auto_get_cancel['start_num']+1;
		   	$can_number = str_pad($inc_value_sub, 6, "0", STR_PAD_LEFT);
			$valid_cancel_number=AutoidTable::updateAll(['start_num' => $can_number,'updated_at' => date('Y-m-d H:i:s'),'ipaddress'=> $_SERVER['REMOTE_ADDR']], ['auto' => 5]);
			
			
			$sub_visit=$_POST['subVisit_sub_visit'];
			$mr_number=$_POST['subVisit_mr_number'];
			$patient_name=$_POST['newpatient_patientname'];
			$patient_age=$_POST['newpatient_pat_age'];
			$patient_sex=$_POST['newpatient_pat_sex'];
			$physican_name=$_POST['subVisit_consultant_doctor'];
			$opd_type=$_POST['cancelLogTable_opd_type'];
			$new_amount=$_POST['subVisit_net_amt'];
			$cancel_amount=$_POST['cancelLogTable_cancel_amt'];
			$amt_in_words=$_POST['cancelLogTable_amt_words'];
			$paid_amount=$_POST['cancelLogTable_paid'];
			$cancelled_reason=$_POST['cancelLogTable_reason_cancelled'];
			$payment_mode=$_POST['SubVisit']['pay_mode'];
			
			//Cancel Type
			$cancelled_trans_type=$_POST['CancelLogTable']['cancel_trans_type'];
			$cancelled_cancel_type=$_POST['CancelLogTable']['cancel_type'];
			$cancelled_towards=$_POST['CancelLogTable']['towards'];
			$cancelled_refund_type=$_POST['CancelLogTable']['refund_type'];
			
			
			$subvisit_query=SubVisit::find()->where(['sub_visit'=>$sub_visit])->one();
			
			if(!empty($subvisit_query))
			{
				$subvisit_query->refund_status = 'YES';
				if($subvisit_query->save())
				{
					
					
					$cancellog->cancel_ran_id = $can_number;
					$cancellog->cancel_trans_type = $cancelled_trans_type;
					$cancellog->cancel_type = $cancelled_cancel_type;
					$cancellog->subvisitno = $sub_visit;
					$cancellog->mrnumber = $mr_number;
					$cancellog->opd_type = $opd_type;
					$cancellog->towards = $cancelled_towards;
					$cancellog->refund_type = $cancelled_refund_type;
					$cancellog->payment_mode = $payment_mode;
					$cancellog->doctor_fees = $new_amount;
					$cancellog->cancel_amt = $new_amount;
					$cancellog->amt_words = $amt_in_words;
					$cancellog->paid = $paid_amount;
					$cancellog->reason_cancelled = $cancelled_reason;
					$cancellog->created_at =date('Y-m-d H:i:s');
					$cancellog->ip_address =$_SERVER['REMOTE_ADDR'];
					$cancellog->user_id =$session['user_id'];
					if($cancellog->save())
					{
						return $this->redirect(['index']);
					}
					else 
					{
						print_r($cancellog->getErrors());die;
					}	
				}
			}
		}
		else 
		{
			$insurancelist=ArrayHelper::map(Insurance::find()->where(['is_active'=>1])->asArray()->all(), 'insurance_typeid', 'insurance_type');
		
			$physicianmaster=ArrayHelper::map(Physicianmaster::find()->where(['is_active'=>1])->asArray()->all(), 'id', 'physician_name');
			
			$specialistdoctor=ArrayHelper::map(Specialistdoctor::find()->where(['is_active'=>1])->asArray()->all(), 's_id', 'specialist');
			
			$paymenttype=ArrayHelper::map(PaymentType::find()->where(['is_active'=>1])->asArray()->all(), 'payment_type_id', 'paymenttype');
			
			$patienttype=ArrayHelper::map(Patienttype::find()->where(['is_active'=>1])->asArray()->all(), 'type_id', 'patient_type');
			
			return $this->render('cancelopd', [
	            'subvisit' => $subvisit,
	            'cancellog' => $cancellog,
	            'newpatient' => $newpatient,
	            'paymenttype' => $paymenttype,
	            'physicianmaster' => $physicianmaster,
	        ]);
		}
		
	}
}
