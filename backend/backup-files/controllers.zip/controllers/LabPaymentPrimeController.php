<?php

namespace backend\controllers;

use Yii;
use backend\models\LabPaymentPrime;
use backend\models\LabPaymentPrimeSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\models\LabPayment;
use backend\models\LabPaymentSearch;
use yii\helpers\ArrayHelper;
use backend\models\Testgroup;
use backend\models\LabTesting; 
use backend\models\TaxgroupingLog; 
use backend\models\NewPatient; 
use backend\models\SubVisit; 
use backend\models\Physicianmaster;
use backend\models\Insurance; 
use backend\models\LabTestgroup; 
use backend\models\LabUnit;
use backend\models\LabReferenceVal; 
/**
 * LabPaymentPrimeController implements the CRUD actions for LabPaymentPrime model.
 */
class LabPaymentPrimeController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all LabPaymentPrime models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LabPaymentPrimeSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	
	public function actionLabIndexGrid()
    {
       $searchModel = new LabPaymentPrimeSearch();
        $dataProvider = $searchModel->searchlabtest(Yii::$app->request->queryParams);

        return $this->render('labtestpending', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	public function actionReport($id)
    { 
    	$model = $this->findModel($id);
    	$newpatient=Newpatient::find()->where(['mr_no'=>$model->mr_number])->asArray()->one();
		$sub_visit=SubVisit::find()->where(['mr_number'=>$model->mr_number])->orderBy(['sub_id'=>SORT_DESC])->asArray()->one();
		$physicianmaster=Physicianmaster::find()->where(['id'=>$sub_visit['consultant_doctor']])->asArray()->one();
		$insurance=Insurance::find()->where(['insurance_typeid'=>$sub_visit['insurance_type']])->asArray()->one();
		$lab_payment=LabPayment::find()->where(['lab_prime_id'=>$model->lab_id])->asArray()->all();
		
		$age=$this->Getage($newpatient['dob']);
		
		//print_r($model->lab_id); die;
		$set_id=array();
		if(!empty($lab_payment))
		{
			foreach ($lab_payment as $key => $value) 
			{
				if($value['lab_testgroup'] != '' )
				{
					$hide='show';
					$set_id[]=$value['lab_testgroup'];
				}
			}
			$set_id_val=implode(',', $set_id);
		}
		$id=$model->lab_id;
		$setid=$set_id_val;
		if($id != '' && $setid != '')
		{	$set=explode(',', $setid);
			$lab_payment=LabPayment::find()->where(['lab_prime_id'=>$id])->andWhere(['in','lab_testgroup',$set])->asArray()->all();
		}
		
		
    	if($_POST)
		{
			//echo '<pre>';
			//print_r($_POST);die;
			if($_POST['Save_Group']== 'Save Grouping')
			{
				$data=array();
				$date_id=date('Y-m-d H:i:s');
				$session = Yii::$app -> session;
				foreach ($_POST['TESTNAME'] as $key => $value) 
				{
					$data[]=['N',$value,$_POST['LabTesting'][$key],$_POST['TESTNAMEID'][$key],$_POST['LABPAYMENTID'][$key],$_POST['LabTestgroup'][$key],
								
							$_POST['MRNUMBER'][$key],$_POST['RESULT'][$key],$_POST['UNITNAME'][$key],$_POST['REFERENCENAME'][$key],$_POST['TextArea'],'T',$date_id,$session['user_id'],$_SERVER['REMOTE_ADDR']
					];
				}

		
			
			
				//$data_count=count($data);
				$status_count=Yii::$app->db->createCommand()->batchInsert('lab_report', ['status','testname', 'lab_testing','testname_id','lab_payment_id',
				
				'lab_test_group','mr_number','result','unit_name','reference_name','textarea','grouping_status','created_at','user_id','updated_ipaddress'],$data)->execute();
				
				Yii::$app->getSession()->setFlash('success', 'Saved Successfully.');  
					return $this->redirect(['lab-index-grid']);
			
			}
			
		} 
		else
		{
			return $this->render('payment_page', [
            'model' => $model,
            'newpatient' => $newpatient,
            'sub_visit' => $sub_visit,
            'physicianmaster' => $physicianmaster,
            'insurance' => $insurance,
            'age' => $age,
            'lab_payment' => $lab_payment,
            'lab_testgroup'=>$lab_testgroup,
        	]);
		}
	}
	
	
	public function actionGrouppack($id,$setid)
    { 
		if($id != '' && $setid != '')
		{
			$set=explode(',', $setid);
			$lab_payment=LabPayment::find()->where(['lab_prime_id'=>$id])->andWhere(['in','lab_testgroup',$set])->asArray()->all();
			if(!empty($lab_payment))
			{
				$result_string='';
				
				foreach ($lab_payment as $key => $value) 
				{
					$lab_testgroup=LabTestgroup::find()->where(['testgroupid'=>$value['lab_testgroup']])->asArray()->all();
					if(!empty($lab_testgroup))
					{
						foreach ($lab_testgroup as $key1 => $value1) 
						{
							$lab_testing=LabTesting::find()->where(['autoid'=>$value1['test_nameid']])->asArray()->one();
							$lab_unit=LabUnit::find()->where(['auto_id'=>$lab_testing['unit_id']])->asArray()->one();
							$lab_reference_val=LabReferenceVal::find()->where(['test_id'=>$lab_testing['autoid']])->asArray()->one();
							$result_string.='<table class="table table-bordered algincss"><thead><tr><th>Test Name</th><th>Result</th><th>Units</th><th>Method</th><th>Normal Values</th><th>Description</th></tr></thead>';
    						$result_string.='<tbody>';
							$result_string.='<tr>';
							$result_string.='<td>'.$lab_testing['test_name'].'<input type="hidden" name="TESTNAME[]" value='.$lab_testing['test_name'].' >
								<input type="hidden" name="LabTesting[]" value='.$value['lab_testing'].'>
							<input type="hidden" name="TESTNAMEID[]" value='.$value['lab_prime_id'].'>
							<input type="hidden" name="LABPAYMENTPRIME[]" value='.$value['lab_prime_id'].'>
							<input type="hidden" name="LABPAYMENTID[]" value='.$value['autoid'].'>
							<input type="hidden" name="LabTestgroup[]" value='.$value['lab_testgroup'].'>
						
							
							<input type="hidden" name="MRNUMBER[]" value='.$value['mr_number'].'>
							
							</td>';
							$result_string.='<td><input type="text" class="form-control" name="RESULT[]" required></td>';
							$result_string.='<td>'.$lab_unit['unit_name'].'<input type="hidden" name="UNITNAME[]" value='.$lab_unit['unit_name'].'></td>';
							$result_string.='<td></td>';
							$result_string.='<td>'.$lab_reference_val['ref_from'].'-'.$lab_reference_val['ref_to'].'<input type="hidden" name="REFERENCENAME[]" value='.$lab_reference_val['ref_from'].'-'.$lab_reference_val['ref_to'].'></td>';
							$result_string.='<td></td>';
							$result_string.='</tr></tbody></table>';
						}
						
						
					}
					
				}

					
			}
			
			$result_string.='<div class="row"><div class="col-sm-6"><textarea rows="4" cols="50" name="TextArea"></textarea></div>';
			$result_string.='<div class="col-sm-6"><input class="btn btn-success" type="submit" name="Save_Group" style="float:right;position: relative;top: 60px;" value="Save Grouping"></div></div>';
			echo $result_string;
		}
	}
	
	
    /**
     * Displays a single LabPaymentPrime model.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }
	
	
	public function actionViewlab($id)
    {
    	$lab_payment_prime=LabPaymentPrime::find()->where(['lab_id'=>$id])->asArray()->one();
		$result_string='';
		if(!empty($lab_payment_prime))
		{
			$new_patient=Newpatient::find()->where(['mr_no'=>$lab_payment_prime['mr_number']])->asArray()->one();
			$test_list_det=ArrayHelper::map(LabPayment::find()->where(['lab_prime_id'=>$id])->asArray()->all(), 'autoid', 'lab_testing');
			$result = ArrayHelper::index($test_list_det, 'lab_testing');
		//		echo "<pre>"; print_r($test_list_det); die;
		 $val="";
			if(!empty($new_patient))
			{
					if($new_patient['insurance'] !=""){  $val=$new_patient['insurance']; }else{ $val="NIL";  }
				$result_string.='<table class="table table-bordered">';
				$result_string.='<thead><tr><th>MR Number</th><th>Patient Name</th><th>Age</th><th>Patient Sex</th><th>Mobile No</th><th>Last Consultant Doctor</th><th>Insurance</th></tr></thead>';
                $result_string.='<tbody><tr><td>'.$new_patient['mr_no'].'</td><td>'.$new_patient['patientname'].'</td><td>'.$new_patient['pat_age'].'</td><td>'.$new_patient['pat_sex'].'</td><td>'.$new_patient['pat_mobileno'].'</td><td>'.$lab_payment_prime['physican_name'].'</td><td>'. $val .'</td></tr></body></table>';
				
    			$result_string.='<h4 style="margin-top: 8%;background: #ffacac;color: #fff;text-align: center;padding: 7px 0;margin-bottom: 1px;"> Testing List</h4>';
    			$result_string.='<table class="table table-bordered">';
				$result_string.='<thead><tr><th>Test Name</th><th> Unit </th><th>Amount</th></tr></thead>';
				$result_string.='<tbody>';
				foreach ($test_list_det as $value) {
				// echo "<pre>";
				$labtesting=LabTesting::find()->where(['autoid'=>$value])->all();
				 // print_r($labtesting); die;
				  foreach ($labtesting as $value) {
				  	$unit_det=LabUnit::find()->where(['auto_id'=>$value['unit_id']])->asArray()->all();
					
						$result_string.='<tr><td>'.$value['test_name'].'</td><td>'.$unit_det[0]['unit_name'].'</td> <td>'.$value['price'].'</td></tr>';						
					}
				} 
               $result_string.='</body></table>';
			}
		}
		
    	
 		 echo $result_string;
    }
	
    /**
     * Creates a new LabPaymentPrime model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new LabPayment();
		$main = new  LabPaymentPrime();
		$labtesting=ArrayHelper::map(LabTesting::find()->where(['isactive'=>'1'])->all(), 'autoid', 'test_name');
		$testgroup=ArrayHelper::map(Testgroup::find()->where(['isactive'=>'1'])->all(),'autoid','testgroupname');
		$session = Yii::$app->session;
		$user_id=$session['user_id'];
        if ($main->load(Yii::$app->request->post())) 
        {
        	
			$LabPaymentPrime = new  LabPaymentPrime();
        	$lap_payment=Yii::$app->request->post('LabPayment')['lab_common_id'];
			
			$over_all_discount_type=Yii::$app->request->post('overall_discount_type');
			$overall_discount_percent=Yii::$app->request->post('overall_discount_percent');
			$overall_discount_amount=Yii::$app->request->post('total_disc_original');
			
			
			
			if(empty($lap_payment))
			{
				Yii::$app->getSession()->setFlash('error', 'Lab Test Not Inserting.');
				return $this->redirect(['lab-payment-prime/index']);
			}
			else if(!empty($lap_payment))
			{
				foreach ($lap_payment as $key => $value) 
				{
					$split_group=explode('_', $value);
					$split_group_d[]=explode('_', $value);
					if($split_group[0] == 'LabTesting')
					{
						$lab_array[]=$split_group[1];
					}
					elseif ($split_group[0] == 'TestGroup') 
					{
						$group_array[]=$split_group[1];
					}
				}
				
				if(!empty($lab_array))
				{
					$lab_testing=LabTesting::find()->where(['IN','autoid',$lab_array])->asArray()->all();
					$lab_testing_index=ArrayHelper::index($lab_testing,'autoid');
					
					$tax_grouping_map_lab=ArrayHelper::map($lab_testing,'autoid','hsncode');
					$testgroup_lab=TaxgroupingLog::find()->where(['IN','taxgroupid',$tax_grouping_map_lab])->andWhere(['is_active'=>1])->asArray()->all();
					$testgroup_index=ArrayHelper::index($testgroup_lab,'taxgroupid');
				
					
				}
				if(!empty($group_array))
				{
					$test_group=Testgroup::find()->where(['IN','autoid',$group_array])->asArray()->all();
					
					$test_group_index=ArrayHelper::index($test_group,'autoid');
					
					$tax_grouping_map_test=ArrayHelper::map($test_group,'autoid','hsncode');
					$testgroup_test=TaxgroupingLog::find()->where(['IN','taxgroupid',$tax_grouping_map_test])->andWhere(['is_active'=>1])->asArray()->all();
					$testgroup_index_group=ArrayHelper::index($testgroup_test,'taxgroupid');
				}
				
				
				
				$LabPaymentPrime->mr_number=Yii::$app->request->post('LabPaymentPrime')['mr_number'];
				$LabPaymentPrime->name=Yii::$app->request->post('LabPaymentPrime')['name'];
				$LabPaymentPrime->ph_number=Yii::$app->request->post('LabPaymentPrime')['ph_number'];
				$LabPaymentPrime->physican_name=Yii::$app->request->post('LabPaymentPrime')['physican_name'];
				$LabPaymentPrime->insurance=Yii::$app->request->post('LabPaymentPrime')['insurance'];
				$LabPaymentPrime->dob=date('Y-m-d',strtotime(Yii::$app->request->post('LabPaymentPrime')['insurance']));
				$LabPaymentPrime->lab_common_id='Dummy';
				$LabPaymentPrime->created_at=date('Y-m-d H:i:s');
				$LabPaymentPrime->user_id=$user_id;
				$LabPaymentPrime->updated_ipaddress=$_SERVER['REMOTE_ADDR'];
				
				if($LabPaymentPrime->save())
				{
					$overall_item=count($split_group_d);
					$overall_sub_total=0;
					$overall_gst_percentage=0;
					$overall_cgst_percentage=0;
					$overall_sgst_percentage=0;
					$overall_gst_amount=0;
					$overall_cgst_amount=0;
					$overall_sgst_amount=0;
					$overall_net_amount=0;
				
			   
				foreach ($split_group_d as $key => $value) 
				{
					$labpayment=new LabPayment();
					$labpayment->mr_number = Yii::$app->request->post('LabPaymentPrime')['mr_number'];
					$labpayment->lab_prime_id=$LabPaymentPrime->lab_id;
					$labpayment->paid_status = 'Y';
					$labpayment->lab_common_id =$lap_payment[$key];
					if($value[0] == 'LabTesting')
					{
						if(isset($lab_testing_index[$value[1]]['hsncode']))
						{
							$hsn_id=$lab_testing_index[$value[1]]['hsncode'];
							
							if(isset($testgroup_index[$hsn_id]))
							{
								$gst_percentage=$testgroup_index[$hsn_id]['tax'];
								$percentage=$gst_percentage/2;
							}
						}
						
						$labpayment->lab_testing =$value[1];
						//GST Percentage
						$labpayment->gst_percentage =$gst_percentage;
						$labpayment->cgst_percentage =$percentage;
						$labpayment->sgst_percentage =$percentage;
						//GST Amount
						$gst_amount=($gst_percentage*$lab_testing_index[$value[1]]['price'])/100;
						$cgst_sgst_amount=($percentage*$lab_testing_index[$value[1]]['price'])/100;
						$labpayment->gst_amount =$gst_amount;
						$labpayment->cgst_amount =$cgst_sgst_amount;
						$labpayment->sgst_amount =$cgst_sgst_amount;
						$labpayment->total_amount =$lab_testing_index[$value[1]]['price'];
						$labpayment->hsn_code =$lab_testing_index[$value[1]]['hsncode'];
						$labpayment->net_amount=$gst_amount+$lab_testing_index[$value[1]]['price'];
					}
					elseif ($value[0] == 'TestGroup') 
					{
						$labpayment->lab_testgroup = $value[1];
						
						if(isset($test_group_index[$value[1]]['hsncode']))
						{
							$hsn_id=$test_group_index[$value[1]]['hsncode'];
							if(isset($testgroup_index_group[$hsn_id]))
							{
								$gst_percentage=$testgroup_index_group[$hsn_id]['tax'];
								$percentage=$gst_percentage/2;
							}
						}
						
						$labpayment->lab_testing =$value[1];
						//GST Percentage
						$labpayment->gst_percentage =$gst_percentage;
						$labpayment->cgst_percentage =$percentage;
						$labpayment->sgst_percentage =$percentage;
						//GST Amount
						$gst_amount=($gst_percentage*$test_group_index[$value[1]]['price'])/100;
						$cgst_sgst_amount=($percentage*$test_group_index[$value[1]]['price'])/100;
						$labpayment->gst_amount =$gst_amount;
						$labpayment->cgst_amount =$cgst_sgst_amount;
						$labpayment->sgst_amount =$cgst_sgst_amount;
						$labpayment->total_amount =$test_group_index[$value[1]]['price'];
						$labpayment->hsn_code =$test_group_index[$value[1]]['hsncode'];
						$labpayment->net_amount=$gst_amount+$test_group_index[$value[1]]['price'];
					}
					
						$labpayment->user_id=$user_id;
						$labpayment->created_at=date('Y-m-d H:i:s');
						$labpayment->ip_address=$_SERVER['REMOTE_ADDR'];
							
						if($labpayment->save())
						{
							$overall_sub_total=$overall_sub_total+$labpayment->total_amount;
							$overall_gst_percentage=$overall_gst_percentage+$labpayment->gst_percentage;
							$overall_cgst_percentage=$overall_cgst_percentage+$labpayment->cgst_percentage;
							$overall_sgst_percentage=$overall_sgst_percentage+$labpayment->sgst_percentage;
							$overall_gst_amount=$overall_gst_amount+$labpayment->gst_amount;
							$overall_cgst_amount=$overall_cgst_amount+$labpayment->cgst_amount;
							$overall_sgst_amount=$overall_sgst_amount+$labpayment->sgst_amount;
							$overall_net_amount=$overall_net_amount+$labpayment->net_amount;
							
							$percentage=0;
							$gst_percentage=0;
						}
						else 
						{
							print_r($labpayment->getErrors());die;
						}
				  }
					
				
					
					if($over_all_discount_type == 'F' || $over_all_discount_type == 'P')
					{
						$overall_net_amount=$overall_net_amount-$overall_discount_amount;
						$updated=LabPaymentPrime::updateAll(['overall_item'=>$overall_item,'overall_gst_per'=>$overall_gst_percentage,'overall_cgst_per'=>$overall_cgst_percentage,
												'overall_sgst_per'=>$overall_sgst_percentage,'overall_gst_amt'=>$overall_gst_amount,'overall_cgst_amt'=>$overall_cgst_amount,
												'overall_sgst_amt'=>$overall_sgst_amount,'overall_sub_total'=>$overall_sub_total,'overall_net_amt'=>$overall_net_amount,
												'overall_dis_type'=>$over_all_discount_type,'overall_dis_percent'=>$overall_discount_percent,
												'overall_dis_amt'=>$overall_discount_amount,'payment_status'=>'P'],['lab_id'=>$LabPaymentPrime->lab_id]);
						
						if($updated == 1)
						{
								Yii::$app->getSession()->setFlash('success', 'Lab Success fully Inserted');
								return $this->redirect(['lab-payment-prime/index']);
						}
					}
					else 
					{
						
						$updated=LabPaymentPrime::updateAll(['overall_item'=>$overall_item,'overall_gst_per'=>$overall_gst_percentage,'overall_cgst_per'=>$overall_cgst_percentage,
												'overall_sgst_per'=>$overall_sgst_percentage,'overall_gst_amt'=>$overall_gst_amount,'overall_cgst_amt'=>$overall_cgst_amount,
												'overall_sgst_amt'=>$overall_sgst_amount,'overall_sub_total'=>$overall_sub_total,'overall_net_amt'=>$overall_net_amount,'payment_status'=>'P'],['lab_id'=>$LabPaymentPrime->lab_id]);
						
						if($updated == 1)
						{
								Yii::$app->getSession()->setFlash('success', 'Lab Success fully Inserted');
								return $this->redirect(['lab-payment-prime/index']);
						}
					}
					
					
					
				}
				else {
					print_r($LabPaymentPrime->getErrors());die;
				}
			}
        	
        }
		else 
		{
			 return $this->render('create', [
	            'model' => $main,
	            'labtesting' => $labtesting,
	            'testgroup'=>$testgroup,
	            'main' =>  $model,
        	]);
		}
    }

    /**
     * Updates an existing LabPaymentPrime model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->lab_id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }
	
	
	public function actionLabset($id)
    {
       if($id != '')
	   {
	   		$split_group=explode('_', $id);
			$result_string='';
			if($split_group[0] == 'LabTesting')
			{
				$lab_testing=LabTesting::find()->where(['autoid'=>$split_group[1]])->asArray()->one();
				
				
				
				$hsn_code=$lab_testing['hsncode'];
				$tax_grouping_log=TaxgroupingLog::find()->where(['taxgroupid'=>$hsn_code])->andWhere(['is_active'=>1])->one();
				$percentage=$tax_grouping_log['tax'];
				
				$gstpercent_divided=$percentage/2;
				
				$calculation=($lab_testing['price']*$percentage)/100;
				
				if(!empty($lab_testing))
				{
					$result_string.='<tr class="calculation" id="lab_test'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">';
					$result_string.='<td style="text-align:center" id="lab_name'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.$lab_testing['test_name'].'<input type="hidden" name="LabPayment[lab_common_id][]" value="'.$id.'" ></td>';
				    $result_string.='<td style="text-align:center" id="price_test_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.number_format($lab_testing['price'],2, '.', '').'</td>';
				   
					//$result_string.='<td  style="text-align:center" id="gst_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.number_format($calculation,2, '.', '').'</td>';
				   $result_string.='<td  style="text-align:center" id="cgst_per_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.number_format($gstpercent_divided,2, '.', '').'</td>';
				   $result_string.='<td  style="text-align:center" id="sgst_per_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.number_format($gstpercent_divided,2, '.', '').'</td>';
				   
				   $result_string.='<td  style="text-align:center" id="cgst_amt_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.number_format(($lab_testing['price']*$gstpercent_divided/100),2, '.', '').'</td>';
				   $result_string.='<td  style="text-align:center" id="sgst_amt_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.number_format(($lab_testing['price']*$gstpercent_divided/100),2, '.', '').'</td>';
				   
				    $result_string.='<td  style="text-align:center" id="net_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'">'.number_format($calculation+$lab_testing['price'],2, '.', '').'</td>';
					$result_string.='<td  style="text-align:center"  id="remove_lab'.$lab_testing['autoid'].'" dataid="LabTesting_'.$lab_testing['autoid'].'"><button dataid="LabTesting_'.$lab_testing['autoid'].'" class="remove btn btn-danger btn-xs" type="button"><i class="glyphicon glyphicon-remove" aria-hidden="true"></i></button></td>';
					$result_string.='</tr>';
				}
			
			}
			elseif ($split_group[0] == 'TestGroup') 
			{
				$testgroup=Testgroup::find()->where(['autoid'=>$split_group[1]])->asArray()->one();
				
				$hsn_code=$testgroup['hsncode'];
				$tax_grouping_log=TaxgroupingLog::find()->where(['taxgroupid'=>$hsn_code])->andWhere(['is_active'=>1])->one();
				$percentage=$tax_grouping_log['tax'];
				$gstpercent_divided=$percentage/2;
				
				$calculation=($testgroup['price']*$percentage)/100;
				
				if(!empty($testgroup))
				{
					$result_string.='<tr class="calculation"  id="test_group'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">';
					$result_string.='<td style="text-align:center" id="test_group_name'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.$testgroup['testgroupname'].'<input type="hidden" value="'.$id.'"  name="LabPayment[lab_common_id][]"></td>';
				    $result_string.='<td style="text-align:center" id="price_test_group'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.number_format($testgroup['price'],2, '.', '').'</td>';
				   
					//$result_string.='<td style="text-align:center" id="gst_test_group'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.number_format($calculation,2, '.', '').'</td>';
				     $result_string.='<td  style="text-align:center" id="cgst_per_test'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.number_format($gstpercent_divided,2, '.', '').'</td>';
				   	 $result_string.='<td  style="text-align:center" id="sgst_per_test'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.number_format($gstpercent_divided,2, '.', '').'</td>';
				   
				   	 $result_string.='<td  style="text-align:center" id="cgst_amt_test'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.number_format(($testgroup['price']*$gstpercent_divided/100),2, '.', '').'</td>';
				     $result_string.='<td  style="text-align:center" id="sgst_amt_test'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.number_format(($testgroup['price']*$gstpercent_divided/100),2, '.', '').'</td>';
				  
				     $result_string.='<td style="text-align:center" id="net_test_group'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'">'.number_format($calculation+$testgroup['price'],2, '.', '').'</td>';
					 $result_string.='<td style="text-align:center" id="remove_test_group'.$testgroup['autoid'].'" dataid="TestGroup_'.$testgroup['autoid'].'"><button dataid="TestGroup_'.$testgroup['autoid'].'"  class="remove btn btn-danger btn-xs"  type="button"><i class="glyphicon glyphicon-remove" aria-hidden="true"></i></button></td>';
					 $result_string.='</tr>';
				}
			
			}

			return $result_string;
	   
		}   
    }

    /**
     * Deletes an existing LabPaymentPrime model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
	
    /**
     * Finds the LabPaymentPrime model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return LabPaymentPrime the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = LabPaymentPrime::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
	
	public function Getage($userDob)
	{
		
		//Create a DateTime object using the user's date of birth.
		$dob = new \DateTime($userDob);
		//We need to compare the user's date of birth with today's date.
		$now = new \DateTime();
		//Calculate the time difference between the two dates.
		$difference = $now->diff($dob);
		//Get the difference in years, as we are looking for the user's age.
		$age = $difference->y;
		//Print it out.
		return $age;
	}
	public function actionPrint($id)
    {
		$pdf_mode = new LabPaymentPrime();
		$getjobid=$id;
		
		$id=base64_decode(urldecode($id));
		$pdf_mode->jobcardprint($getjobid);	
       		 
    }
}
