<?php 
use yii\helpers\Html;
$this->title = "Update Saledetail";
echo $this->render('wizardform',['model' =>$model]);?>