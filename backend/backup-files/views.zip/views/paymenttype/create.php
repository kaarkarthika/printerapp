<?php
use yii\helpers\Html;
$this->title = Yii::t('app', 'Create Paymenttype');
echo $this->render('_form', [ 'model' => $model])
 ?>