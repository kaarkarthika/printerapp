<?php
use yii\helpers\Html;

use yii\helpers\Url;
use yii\bootstrap\ActiveForm;

use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */

$this->title = 'DMC PHARMACY - Dashboard';

//Set Default Timezone
date_default_timezone_set('Asia/Kolkata');

?>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Dashboard</title>
 
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  
  
  
  
</head>


<body class="hold-transition skin-blue sidebar-mini">

    

</body>
</html>
  
