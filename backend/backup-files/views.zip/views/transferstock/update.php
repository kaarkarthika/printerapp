<?php

use yii\helpers\Html;
echo $this->render('_updateform', [
        'model' => $model,
    ]) ?>

</div>
